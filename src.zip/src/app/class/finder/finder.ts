export class Finder {

    userID!: string;
    contribuableID!: string;
    categorieID!: string;
    localiteID!: string;
    communeID!: string;
    zoneID!: string;
    dateMin!: string;
    dateMax!: string;
    dateEmission!: string;
    etat!: number;
    niveau!: number;
    strategie!: number;
    typeID!: number;
    millesime!: string;
    reference!: string;
objet!: string;
type!: string;
classeur!: string;
autre!: string;


}
