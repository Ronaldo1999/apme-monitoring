import { Finder } from './finder';

describe('Finder', () => {
  it('should create an instance', () => {
    expect(new Finder()).toBeTruthy();
  });
});
