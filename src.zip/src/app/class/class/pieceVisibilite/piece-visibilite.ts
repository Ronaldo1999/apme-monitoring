export class PieceVisibilite {
     id:string='';
     name?:string;
     url?:string;
     type?:string;
     size?:number;
     data:any
     userupdate!:string;
     ipupdate!:string;
     visibilite!:boolean
}
