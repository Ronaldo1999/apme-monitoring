export class Piecejointe {
    idPieceJointe!:string
    idCourrierType!:string
    libelleFr!:string
    libelleUs!:string
    userupdate!:string;
       ipupdate!:string;
}
