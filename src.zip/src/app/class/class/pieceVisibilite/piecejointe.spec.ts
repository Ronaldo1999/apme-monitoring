import { Piecejointe } from './piecejointe';

describe('Piecejointe', () => {
  it('should create an instance', () => {
    expect(new Piecejointe()).toBeTruthy();
  });
});
