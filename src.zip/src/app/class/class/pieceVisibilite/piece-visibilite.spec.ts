import { PieceVisibilite } from './piece-visibilite';

describe('PieceVisibilite', () => {
  it('should create an instance', () => {
    expect(new PieceVisibilite()).toBeTruthy();
  });
});
