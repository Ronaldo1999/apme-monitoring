import { Token } from "@angular/compiler"
import { TokenStorageService } from "src/app/auth/_services/token-storage.service"

export class User {
    
    login:string=''
    password:string=''
    nom:string=''
    prenom:string=''
    telephone:string=''
    organisationID:string=''
    structureID:string=''
    fonction:string=''
    email:string=''
    actif!:boolean
    service:string=''
    facebook:string=''
    whatsapp:string=''
    twitter:string=''
    googleplus:string=''
    linkedln:string=''
    userUpdate!:string
    ipUpdate:string=''
    dateCreation:any
    structure!:string
    loginParent!:string
    code!:string;
    codeParent!:string;
    chaine!:string;
    profilPerformance!:string;

}
