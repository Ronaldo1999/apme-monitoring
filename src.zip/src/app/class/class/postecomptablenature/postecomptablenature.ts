export class Postecomptablenature {
    user_update!: string
    ip_update!: string
    last_update!: string
    libelleFr!: string
    libelleUs!: string
    naturePC!: string
    postecomptableCount!: number
}
