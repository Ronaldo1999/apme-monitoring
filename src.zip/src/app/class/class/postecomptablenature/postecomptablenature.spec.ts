import { Postecomptablenature } from './postecomptablenature';

describe('Postecomptablenature', () => {
  it('should create an instance', () => {
    expect(new Postecomptablenature()).toBeTruthy();
  });
});
