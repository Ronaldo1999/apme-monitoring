import { UserMessage } from './user-message';

describe('UserMessage', () => {
  it('should create an instance', () => {
    expect(new UserMessage()).toBeTruthy();
  });
});
