import { Message } from "../messages/message";
import { User } from "../user/user";

export class UserMessage {

    
    message= new Message();
    users: User[]=[]
}
