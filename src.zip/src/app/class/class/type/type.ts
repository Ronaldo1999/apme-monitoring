export class Type {
    idCourrierType!:string
    libelleFr!:string
    libelleUs!:string
    code!:string
    userupdate!:string;
    ipupdate!:string;
}
