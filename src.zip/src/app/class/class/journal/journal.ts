export class Journal {

   courrierjournalID:string=''
   _date:string=''
   operation:string=''
   userID:string=''
   courrierID:string=''
   username:string=''
 
}
