import { Journal } from './journal';

describe('Journal', () => {
  it('should create an instance', () => {
    expect(new Journal()).toBeTruthy();
  });
});
