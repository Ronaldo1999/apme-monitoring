import { Systeme } from './systeme';

describe('Systeme', () => {
  it('should create an instance', () => {
    expect(new Systeme()).toBeTruthy();
  });
});
