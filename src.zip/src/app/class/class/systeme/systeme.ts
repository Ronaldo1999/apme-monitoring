export class Systeme {
    last_update:any
    user_update:any
    ip_update:any
    systemeID!:string
    libelleFr!:string
    libelleUs!:string
    numOrdre!:number
    icon :string=''
    iconRole :string=''
   
}
