import { TokenStorageService } from 'src/app/auth/_services/token-storage.service';
import { Courrier } from './courrier';

describe('Courrier', () => {
  it('should create an instance', () => {
    expect(new Courrier()).toBeTruthy();
  });
});

