import { GroupeGlobal } from './groupe-global';

describe('GroupeGlobal', () => {
  it('should create an instance', () => {
    expect(new GroupeGlobal()).toBeTruthy();
  });
});
