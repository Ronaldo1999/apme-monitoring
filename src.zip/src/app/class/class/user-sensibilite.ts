export class UserSensibilite {
    userID:string=''
    sensibiliteID:string=''
}
