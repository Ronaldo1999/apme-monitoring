export class Souscategorie {
      code!:string;
      libelleFr!:string;
      libelleUs!:string;
      last_update!:string;
      user_update:string='admin';
      ip_update!:string;
      abbreviationFr!:string;
      abbreviationUs!:string;
      parent_code!:string;
      niveauID!:string;
      childs!:number;
}
