import { Souscategorie } from './souscategorie';

describe('Souscategorie', () => {
  it('should create an instance', () => {
    expect(new Souscategorie()).toBeTruthy();
  });
});
