export class Localisation {
    localisationID!:string
    libelleFr!:string
    libelleUs!:string
    latitude!:number
    longitude!:number
    lastUpdate!:string
    userUpdate!:string
    ipUpdate!:string
}
