import { Localisation } from './localisation';

describe('Localisation', () => {
  it('should create an instance', () => {
    expect(new Localisation()).toBeTruthy();
  });
});
