import { Circuit } from './circuit';

describe('Circuit', () => {
  it('should create an instance', () => {
    expect(new Circuit()).toBeTruthy();
  });
});
