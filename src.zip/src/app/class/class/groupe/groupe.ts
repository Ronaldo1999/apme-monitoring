export class Groupe {
    groupeID!: string;
    user_update!: string;
    systemeID!: string;
    organisationID!: string;
    moduleID!: string;
    libelleFr!: string;
    libelleUs!: string;
    code!: string;
    etat!: number;
}
