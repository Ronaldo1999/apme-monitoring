import { Modebudget } from './modebudget';

describe('Modebudget', () => {
  it('should create an instance', () => {
    expect(new Modebudget()).toBeTruthy();
  });
});
