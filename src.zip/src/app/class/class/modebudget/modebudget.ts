export class Modebudget {
    idCourrierModeBudget:string=''
    code:string=''
    libelleFr!:string
    libelleUs!:string
    userupdate!:string;
       ipupdate!:string;
}
