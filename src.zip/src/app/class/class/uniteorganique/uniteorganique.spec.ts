import { Uniteorganique } from './uniteorganique';

describe('Uniteorganique', () => {
  it('should create an instance', () => {
    expect(new Uniteorganique()).toBeTruthy();
  });
});
