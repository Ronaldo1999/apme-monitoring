export class Uniteorganique {
    last_update!:any
    user_update:string='admin'
    ip_update!:any
    uniteOrganiqueID!:string
    libelleFr!:string
    libelleUs!:string
    ordre!:number
    r!:number
    g!:number
    b!:number
    organisationID!:string
    uniteOrganiqueParentID!:string
    missionsFr!:string
    missionsUs!: string
}
