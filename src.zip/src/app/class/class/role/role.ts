export class Role {
    roleID !: string;
    libelleFr  !: string;
    libelleUs  !: string;
    code  !: string;
    roleParent !: string;
    moduleID !: string;
    organisationID !: string;
    user_update !: string;
}
