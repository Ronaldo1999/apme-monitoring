import { CourrierTransfert } from './courrier-transfert';

describe('CourrierTransfert', () => {
  it('should create an instance', () => {
    expect(new CourrierTransfert()).toBeTruthy();
  });
});
