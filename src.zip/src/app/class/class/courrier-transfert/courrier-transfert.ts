export class CourrierTransfert {

     registreID: string = '';
     courrierID: any;
     bordereauID: string = '';
     numBordereau: string = '';
     userID: string = '';
     dateEntree: string = '';
     dateSortie: string = '';
     pt: string = '';
     pte: string = '';
     ptr: string = '';
     libellePte: string = '';
     libellePtr: string = '';
     bordereauE: string = '';
     bordereauS: string = '';
     dateGenere: string = '';
     responsable: string = '';
     titre: string = '';
     type: string = '';
     userupdate: string = '';
     ipupdate: string = '';
     nbPiecesJointes!: number;
     observation: string = ''
     objet: any

}
