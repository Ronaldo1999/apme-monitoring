export class Modules {
    last_update:any
    user_update:any
    ip_update:any
    moduleID:string=''
    systemeID!:string
    libelleFr!:string
    libelleUs!:string
    numOrdre!:number
    icon:string=''
    iconRoll:string=''
    ordre !:number
}
