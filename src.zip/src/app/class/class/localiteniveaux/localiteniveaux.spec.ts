import { Localiteniveaux } from './localiteniveaux';

describe('Localiteniveaux', () => {
  it('should create an instance', () => {
    expect(new Localiteniveaux()).toBeTruthy();
  });
});
