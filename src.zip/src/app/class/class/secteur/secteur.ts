export class Secteur {
    secteurID!:string
    libelleFr!:string
    libelleUs!:string
    code!:string
    codeCategorie!:string
    codeSousCategorie!:string
    secteurParentID!:string
    numordre:number=0
    fils:number=0
    userupdate!:string;
    ipupdate!:string;
}
