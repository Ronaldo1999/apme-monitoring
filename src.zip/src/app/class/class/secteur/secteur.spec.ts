import { Secteur } from './secteur';

describe('Secteur', () => {
  it('should create an instance', () => {
    expect(new Secteur()).toBeTruthy();
  });
});
