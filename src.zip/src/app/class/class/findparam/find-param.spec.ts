import { FindParam } from './find-param';

describe('FindParam', () => {
  it('should create an instance', () => {
    expect(new FindParam()).toBeTruthy();
  });
});
