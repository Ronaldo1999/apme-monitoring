import { Postecomptable } from './postecomptable';

describe('Postecomptable', () => {
  it('should create an instance', () => {
    expect(new Postecomptable()).toBeTruthy();
  });
});
