export class Postecomptable {

    last_update!:string ;
    user_update!:string ;
    ip_update!:string ;
    posteComptableID!:string;
    code!:string;
    abbreviationFr!:string;
    abbreviationUs!:string;
    libelleFr!:string;
    libelleUs!:string;
    dateCreation!:Date;
    dateCessation!:string;
    actif!:boolean;
    codeLocalite!:string;
    naturePC!:string;

}
