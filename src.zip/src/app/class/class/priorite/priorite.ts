export class Priorite {
    idCourrierPriorite!:string
    libelleFr!:string
    libelleUs!:string
    code!:string
    user_update!:string;
    ip_update!:string;
    last_update!:string;
}
