import { Priorite } from './priorite';

describe('Priorite', () => {
  it('should create an instance', () => {
    expect(new Priorite()).toBeTruthy();
  });
});
