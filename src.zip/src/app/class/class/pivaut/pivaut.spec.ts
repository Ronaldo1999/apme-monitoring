import { Pivaut } from './pivaut';

describe('Pivaut', () => {
  it('should create an instance', () => {
    expect(new Pivaut()).toBeTruthy();
  });
});
