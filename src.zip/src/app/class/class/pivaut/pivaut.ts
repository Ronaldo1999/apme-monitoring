export class Pivaut {
    headers:string[]=[]
    data:any
}
