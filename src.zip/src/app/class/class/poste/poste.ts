export class Poste {
    posteTraitementID!:string
    localisation!:string
    numporte!:string
    libelleFr!:string
    libelleUs!:string
    sensibilite!:string
    structureID!:string
    libelleStructureFr!:string
    libelleStructureUs!:string
    user_update!:string;
    ip_update!:string;
    last_update!:string;
}
