import { Poste } from './poste';

describe('Poste', () => {
  it('should create an instance', () => {
    expect(new Poste()).toBeTruthy();
  });
});
