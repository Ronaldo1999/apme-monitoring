import { Comptabilite } from './comptabilite';

describe('Comptabilite', () => {
  it('should create an instance', () => {
    expect(new Comptabilite()).toBeTruthy();
  });
});
