export class Comptabilite {
    idCourrierComptabilite!:string
    code!:string
    libelleFr!:string
    libelleUs!:string
}
