export class Fonction {
  code: string = '';
  libelleFr: string = '';
  libelleUs!: string;
  last_update!: string;
  user_update!: string;
  ip_update!: string;
  abbreviationFr!: string;
  abbreviationUs!: string;
  parent_code!: string;
  niveauID: number = 1;
  childs!: number;
  children: any

}
