import { Fonction } from './fonction';

describe('Fonction', () => {
  it('should create an instance', () => {
    expect(new Fonction()).toBeTruthy();
  });
});
