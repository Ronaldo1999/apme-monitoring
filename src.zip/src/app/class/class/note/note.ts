export class Note {

    noteID!:string
    courrierID!:string
    responsable!:string
    date!:Date
    destinataire!:string
    contenu!:string
    userupdate!:string

}
