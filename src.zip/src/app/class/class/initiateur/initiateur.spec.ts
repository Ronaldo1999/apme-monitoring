import { Initiateur } from './initiateur';

describe('Initiateur', () => {
  it('should create an instance', () => {
    expect(new Initiateur()).toBeTruthy();
  });
});
