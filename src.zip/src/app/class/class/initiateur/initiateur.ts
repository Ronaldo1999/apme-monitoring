export class Initiateur {
      
      initiateurID!:string;
      courrierID!:string;
      nom!:string;
      prenom!:string;
      email!:string;
      notifier!:boolean;
      telephone!:string;
      userupdate!:boolean;
      ipupdate!:string;

}
