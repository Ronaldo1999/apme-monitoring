export class Localite {
    last_update: any
    user_update: string = 'admin'
    ip_update: any
    localiteID!: string
    parentID!: string
    code!: string
    abbreviationFr!: string
    abbreviationUs!: string
    libelleFr!: string
    libelleUs!: string
    parent_code!: string
    niveauID: number = 1
    nbe!: string
    intext!: string
    decentralisation!: string
    executif!: string
}
