import { RegleGestion } from './regle-gestion';

describe('RegleGestion', () => {
  it('should create an instance', () => {
    expect(new RegleGestion()).toBeTruthy();
  });
});
