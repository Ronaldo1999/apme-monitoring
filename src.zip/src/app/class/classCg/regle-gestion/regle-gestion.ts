export class RegleGestion {

    last_update!: string;
    user_update!: string;
    ip_update!: string;
    reglegestionID!: string;
    libelleFr!: string;
    description!: string;
    libelleUs!: string;
    millesime!: string;
    organisationID!: string;
    creation_date!: string;
}
