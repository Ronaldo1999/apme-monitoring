import { IndicateurCle } from './indicateur-cle';

describe('IndicateurCle', () => {
  it('should create an instance', () => {
    expect(new IndicateurCle()).toBeTruthy();
  });
});
