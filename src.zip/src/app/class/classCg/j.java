


    private String rapportID;
    private String code;
    private String organisationID;
    private String activiteID;
    private String millesime;
    private int version;
    private String dateGenere;
    private String user_update;
    private String last_update;

    private String description;
    private String periode;
    private String 
    private String libelleActivite;
    private String titre;
    private String responsable;
    private String presentation;
    private String objectif;
    private String strategie;

    private String contexte;
    private String performaceGlobale;
    private String difficultes;
    private String recommandations;

