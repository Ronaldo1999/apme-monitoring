import { CharteContent } from './charte-content';

describe('CharteContent', () => {
  it('should create an instance', () => {
    expect(new CharteContent()).toBeTruthy();
  });
});
