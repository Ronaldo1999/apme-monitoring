export class CharteContent {
    charteID!: string;
    organisationID!: string;
    millesime!: string;
    responsable!: string;
    titre!: string;
    description!: string;
    printDesc!: string;
    user_update!: string; last_update!: string
}
