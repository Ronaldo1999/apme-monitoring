import { FactMandat } from './fact-mandat';

describe('FactMandat', () => {
  it('should create an instance', () => {
    expect(new FactMandat()).toBeTruthy();
  });
});
