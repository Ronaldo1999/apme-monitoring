import { SysPerformance } from './sys-performance';

describe('SysPerformance', () => {
  it('should create an instance', () => {
    expect(new SysPerformance()).toBeTruthy();
  });
});
