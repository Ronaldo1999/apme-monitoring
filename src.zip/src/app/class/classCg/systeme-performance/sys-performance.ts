export class SysPerformance {

    last_update!: string;
    user_update!: string;
    ip_update!: string;
    sysperformanceID!: string;
    libelleFr!: string;
    description!: string;
    libelleUs!: string;
    millesime!: string;
    organisationID!: string;
    creation_date!: string;
}
