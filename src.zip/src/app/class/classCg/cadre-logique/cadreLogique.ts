export class CadreLogique {
    cadreLogiqueID!: string;
    code!: string;
    libelleFr!: string;
    libelleUs!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    organisationID!: string;
    structureID!: string;
    creation_date!: string;
}
