import { CgOrganisation } from './cg-organisation';

describe('CgOrganisation', () => {
  it('should create an instance', () => {
    expect(new CgOrganisation()).toBeTruthy();
  });
});
