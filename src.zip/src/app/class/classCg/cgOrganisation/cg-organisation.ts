export class CgOrganisation {
    libelleFr!:string
    datedebut!:Date
    datecloture!:Date
    cloture!:boolean
}
