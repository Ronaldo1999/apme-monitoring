import { CahierCharge } from './cahier-charge';

describe('CahierCharge', () => {
  it('should create an instance', () => {
    expect(new CahierCharge()).toBeTruthy();
  });
});
