import { PrepaBudget } from './prepa-budget';

describe('PrepaBudget', () => {
  it('should create an instance', () => {
    expect(new PrepaBudget()).toBeTruthy();
  });
});
