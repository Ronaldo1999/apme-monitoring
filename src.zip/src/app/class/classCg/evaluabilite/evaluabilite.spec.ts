import { Evaluabilite } from './evaluabilite';

describe('Evaluabilite', () => {
  it('should create an instance', () => {
    expect(new Evaluabilite()).toBeTruthy();
  });
});
