export class Evaluabilite {
    observation!: string
    niveauEvaluation!: string
    decision!: string
    cl1!: boolean
    cl2!: boolean
    cl3!: boolean
    cl4!: boolean
    cl5!: boolean
    cl6!: boolean
    cl7!: boolean
    cl8!: boolean
    cl9!: boolean
    co1!: boolean
    co2!: boolean
    co3!: boolean
    co4!: boolean
    co5!: boolean
    co6!: boolean
    co7!: boolean
    co8!: boolean
    pe1!: boolean
    pe2!: boolean
    pe3!: boolean

}
