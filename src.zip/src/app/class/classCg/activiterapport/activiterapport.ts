export class Activiterapport {

     activiteID!:string;
     periodeEvaluation!:string;
     intitule!:string;
     description!:string;
     responsable!:string;
     periode!:string;
     personnes!:string;
     pg!:string
     pgIndicateur!:string;
     ac!:string;
     acIndicateur!:string;
     at!:string;
     atObjectif!:string;
     atIndicateur!:string;
     activiteObjectif!:string;
     activiteIndicateur!:string;
     activiteResultatAttendu!:string;
     resultatObtenu!:string;
     indicateurObtenu!:string;
     problemes!:string;
     recommandations!:string;
     moyens!:string;
     totalPrev!:number;
     totalRealisation!:number;
     ecart!:number;
     tdrsValides!:number;
     valide:any
     dateSaisie!:number;
     dateValidation!:number;

}
