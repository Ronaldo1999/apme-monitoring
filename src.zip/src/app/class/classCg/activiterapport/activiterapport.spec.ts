import { Activiterapport } from './activiterapport';

describe('Activiterapport', () => {
  it('should create an instance', () => {
    expect(new Activiterapport()).toBeTruthy();
  });
});
