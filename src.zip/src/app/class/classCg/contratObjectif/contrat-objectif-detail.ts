export class ContratObjectifDetail {
    id!: string;
    contratObjectifID!: string;

    objectifSmart!: string;
    strategie!: string;
    activite!: string;
    domaineCle!: string;
    programmeRef!: string;
    actionRef!: string;

    cout!: number;
    user_update!: string; last_update!: string
}
