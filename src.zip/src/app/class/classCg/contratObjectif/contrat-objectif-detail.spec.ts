import { ContratObjectifDetail } from './contrat-objectif-detail';

describe('ContratObjectifDetail', () => {
  it('should create an instance', () => {
    expect(new ContratObjectifDetail()).toBeTruthy();
  });
});
