import { ContratObjectif } from './contrat-objectif';

describe('ContratObjectif', () => {
  it('should create an instance', () => {
    expect(new ContratObjectif()).toBeTruthy();
  });
});
