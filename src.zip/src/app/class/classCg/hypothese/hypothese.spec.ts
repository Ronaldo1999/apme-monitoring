import { Hypothese } from './hypothese';

describe('Hypothese', () => {
  it('should create an instance', () => {
    expect(new Hypothese()).toBeTruthy();
  });
});
