export class Hypothese {
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    clhypotheseID!: string;
    libelleFr!: string;
    libelleUs!: number;
    description!: string;
    code!: string;
    organisationID!: string;
    cadreLogiqueIndicateurID!: string;
    structureID!: string;
    creation_date!: string;
}
