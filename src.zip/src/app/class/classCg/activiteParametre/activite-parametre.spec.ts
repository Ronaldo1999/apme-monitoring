import { ActiviteParametre } from './activite-parametre';

describe('ActiviteParametre', () => {
  it('should create an instance', () => {
    expect(new ActiviteParametre()).toBeTruthy();
  });
});
