export class ActiviteParametre {

    exercice!: string
    organisation !: string
    prepaBudget!: string
    programme: boolean = false
    action: boolean = false
    activite: boolean = false
    reference!: number
    cible !: number
}