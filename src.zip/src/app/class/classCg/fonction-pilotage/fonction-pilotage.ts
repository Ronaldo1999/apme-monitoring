export class FonctionPilotage {

    last_update!: string;
    user_update!: string;
    ip_update!: string;
    fonctionpilogateID!: string;
    libelleFr!: string;
    description!: string;
    libelleUs!: string;
    millesime!: string;
    organisationID!: string;
    fonctionacteurs!: string;
    creation_date!: string;
    acteur!: string;
    descriptionActeur!: string;
   
}
