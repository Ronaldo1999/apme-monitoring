export class Acteur {

    acteurID!: number;
    libelleFr!: string;
    libelleUs!: string;
    description!: string;

}
