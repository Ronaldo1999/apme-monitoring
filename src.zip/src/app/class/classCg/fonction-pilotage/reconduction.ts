export class Reconduction {

    millesime1!: string;
    millesime2!: string;
    organisationID!: string;
    
}
