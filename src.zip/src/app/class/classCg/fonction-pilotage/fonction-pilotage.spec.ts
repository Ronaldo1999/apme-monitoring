import { FonctionPilotage } from './fonction-pilotage';

describe('FonctionPilotage', () => {
  it('should create an instance', () => {
    expect(new FonctionPilotage()).toBeTruthy();
  });
});
