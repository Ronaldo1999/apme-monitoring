export class Compte {

    code!: string
    last_update!: Date
    user_update!: string
    ip_update!: string
    abbreviationFr!: string
    abbreviationUs!: string
    libelleFr!: string
    libelleUs!: string
    parent_code!: string
    niveauID!: number
    childs!: number
    nature!: string
    organisationID!: string
    millesime!: string
    CompteCode!: string
}
