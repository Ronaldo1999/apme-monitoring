import { Compte } from './compte';

describe('Compte', () => {
  it('should create an instance', () => {
    expect(new Compte()).toBeTruthy();
  });
});
