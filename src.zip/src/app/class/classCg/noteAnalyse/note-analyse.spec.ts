import { NoteAnalyse } from './note-analyse';

describe('NoteAnalyse', () => {
  it('should create an instance', () => {
    expect(new NoteAnalyse()).toBeTruthy();
  });
});
