export class MoisBudgetaire {

    moisID!:string
    status!:string
    detail!:string
}
