import { MoisBudgetaire } from './mois-budgetaire';

describe('MoisBudgetaire', () => {
  it('should create an instance', () => {
    expect(new MoisBudgetaire()).toBeTruthy();
  });
});
