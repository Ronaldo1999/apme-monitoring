import { Activiterapportlist } from './activiterapportlist';

describe('Activiterapportlist', () => {
  it('should create an instance', () => {
    expect(new Activiterapportlist()).toBeTruthy();
  });
});
