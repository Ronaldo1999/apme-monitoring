import { DialogueSession } from './dialogue-session';

describe('DialogueSession', () => {
  it('should create an instance', () => {
    expect(new DialogueSession()).toBeTruthy();
  });
});
