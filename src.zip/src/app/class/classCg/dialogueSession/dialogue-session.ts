export class DialogueSession {

    user_update!:string
    last_update!:string
    sessionID!:string 
    libelleFr!:string 
    libelleUs!:string 
    responsable!:string 
    datedebut!:Date
    dateFin!:Date

}
