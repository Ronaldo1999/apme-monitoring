import { Financement } from './financement';

describe('Financement', () => {
  it('should create an instance', () => {
    expect(new Financement()).toBeTruthy();
  });
});
