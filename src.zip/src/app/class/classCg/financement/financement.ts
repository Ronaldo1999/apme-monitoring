export class Financement {
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    financementID!: string;
    libelleFr!: string;
    libelleUs!: string;
    projetID!: string;
    etudeID!: string;
    bailleur!: string;
    coutEstimatif!: number;
    typeFinancement?: string;
    etatFinancement!: string;
}
