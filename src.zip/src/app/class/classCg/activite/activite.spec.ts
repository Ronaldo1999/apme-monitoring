import { Activite } from './activite';

describe('Activite', () => {
  it('should create an instance', () => {
    expect(new Activite()).toBeTruthy();
  });
});
