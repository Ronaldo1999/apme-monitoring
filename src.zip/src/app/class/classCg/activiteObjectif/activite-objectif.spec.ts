import { ActiviteObjectif } from './activite-objectif';

describe('ActiviteObjectif', () => {
  it('should create an instance', () => {
    expect(new ActiviteObjectif()).toBeTruthy();
  });
});
