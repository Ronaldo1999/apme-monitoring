import { PlanAction } from './plan-action';

describe('PlanAction', () => {
  it('should create an instance', () => {
    expect(new PlanAction()).toBeTruthy();
  });
});
