import { PlanActionDetail } from './plan-action-detail';

describe('PlanActionDetail', () => {
  it('should create an instance', () => {
    expect(new PlanActionDetail()).toBeTruthy();
  });
});
