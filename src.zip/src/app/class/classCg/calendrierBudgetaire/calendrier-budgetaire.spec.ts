import { CalendrierBudgetaire } from './calendrier-budgetaire';

describe('CalendrierBudgetaire', () => {
  it('should create an instance', () => {
    expect(new CalendrierBudgetaire()).toBeTruthy();
  });
});
