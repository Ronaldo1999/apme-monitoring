import { IndicateurVar } from './indicateur-var';

describe('IndicateurVar', () => {
  it('should create an instance', () => {
    expect(new IndicateurVar()).toBeTruthy();
  });
});
