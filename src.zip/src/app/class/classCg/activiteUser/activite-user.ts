import { StringMap } from "@angular/compiler/src/compiler_facade_interface"

export class ActiviteUser {

    activiteID !: string
    userID!:string
    last_update!:string
user_update!: string
profil!:string
nom!:string  
prenom!:string
}
