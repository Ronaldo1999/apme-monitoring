import { ActiviteUser } from './activite-user';

describe('ActiviteUser', () => {
  it('should create an instance', () => {
    expect(new ActiviteUser()).toBeTruthy();
  });
});
