import { ActiviteCopie } from './activite-copie';

describe('ActiviteCopie', () => {
  it('should create an instance', () => {
    expect(new ActiviteCopie()).toBeTruthy();
  });
});
