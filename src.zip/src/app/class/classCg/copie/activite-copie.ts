export class ActiviteCopie {

    activiteID !: string
    libelleFr!:string
    libelleUs!:string
    destinatairesID : string[] = []
    user_update!:string


}
