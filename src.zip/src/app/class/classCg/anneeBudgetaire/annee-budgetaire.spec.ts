import { AnneeBudgetaire } from './annee-budgetaire';

describe('AnneeBudgetaire', () => {
  it('should create an instance', () => {
    expect(new AnneeBudgetaire()).toBeTruthy();
  });
});
