export class BcaStatistique {

    traites!: number
    rejetes!: number
    vises!: number
    enCours!: number
    structureID!: string
    libelleStructure!: string
    code !: string
    libelleFr!: string
    libelleUs!: string
    type!: string

}
