import { BcaStatistique } from './bca-statistique';

describe('BcaStatistique', () => {
  it('should create an instance', () => {
    expect(new BcaStatistique()).toBeTruthy();
  });
});
