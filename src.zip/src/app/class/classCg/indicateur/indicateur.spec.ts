import { Indicateur } from './indicateur';

describe('Indicateur', () => {
  it('should create an instance', () => {
    expect(new Indicateur()).toBeTruthy();
  });
});
