import { Mission } from './mission';

describe('Mission', () => {
  it('should create an instance', () => {
    expect(new Mission()).toBeTruthy();
  });
});
