import { LettreMission } from './lettre-mission';

describe('LettreMission', () => {
  it('should create an instance', () => {
    expect(new LettreMission()).toBeTruthy();
  });
});
