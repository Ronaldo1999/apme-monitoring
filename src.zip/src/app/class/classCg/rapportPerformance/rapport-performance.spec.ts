import { RapportPerformance } from './rapport-performance';

describe('RapportPerformance', () => {
  it('should create an instance', () => {
    expect(new RapportPerformance()).toBeTruthy();
  });
});
