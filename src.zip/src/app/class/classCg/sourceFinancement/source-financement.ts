export class SourceFinancement {

    financementID!: string
    last_update!: Date
    user_update!: string
    ip_update!: string
    libelleFr!: string
    libelleUs!: string
    abbreviationFr!: string
    abbreviationUs!: string
    compteCode!: string
    
}
