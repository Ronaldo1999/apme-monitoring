import { SourceFinancement } from './source-financement';

describe('SourceFinancement', () => {
  it('should create an instance', () => {
    expect(new SourceFinancement()).toBeTruthy();
  });
});
