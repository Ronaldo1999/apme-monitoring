export class DialogueTheme {
    themeID!:string
    libelleFr!:string 
    libelleUs!:string 
}
