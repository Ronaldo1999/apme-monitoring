import { DialogueTheme } from './dialogue-theme';

describe('DialogueTheme', () => {
  it('should create an instance', () => {
    expect(new DialogueTheme()).toBeTruthy();
  });
});
