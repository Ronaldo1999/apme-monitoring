export class Financement {
    financementID:string=''
    numordrabbreviationFre:string=''
    abbreviationUs:string=''
    libelleFr:string=''
    libelleUs:string=''
    last_update:string=''
    user_update:string=''
    ip_update:string=''
}
