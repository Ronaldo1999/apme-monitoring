export class Rapport{
    activiteID!:string;
    code!:string;
    comptecode!:string;
    libelleFr!:string;
    dotation!: number;
    dotationcp!: number;
    engages!: number;
    disponible!: number;
    disponiblecp!: number;
    taux!: number;
    tauxcp!: number;
    typeBudget!:number;
    classe!: number;
    organisationID!: string;
    millesime!: string;
}