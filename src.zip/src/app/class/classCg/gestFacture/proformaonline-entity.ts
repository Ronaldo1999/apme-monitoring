export class ProformaonlineEntity {
    id_proforma:string='';
     entreprise:string='' ;
    comptebancaire :string='';
     ht:number=0;
     ir:number=0;
     np:number=0;
    ttc:number=0;
     tauxtva:number=0;
    tauxir:number=0;
     tva:number=0;
     statut:string=''
     objet:string=''
     datecreation:string=''
     lastupdate:string=''
     types:string=''
}
