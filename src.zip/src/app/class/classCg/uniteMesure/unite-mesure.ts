export class UniteMesure {

    UniteMesureID!: string
    libelleFr!: string
    libelleUs!: string
    last_update!: string
    user_update!: string
    ip_update!: string
    code!: string
}
