import { UniteMesure } from './unite-mesure';

describe('UniteMesure', () => {
  it('should create an instance', () => {
    expect(new UniteMesure()).toBeTruthy();
  });
});
