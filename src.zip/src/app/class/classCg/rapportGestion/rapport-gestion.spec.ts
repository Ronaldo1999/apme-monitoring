import { RapportGestion } from './rapport-gestion';

describe('RapportGestion', () => {
  it('should create an instance', () => {
    expect(new RapportGestion()).toBeTruthy();
  });
});
