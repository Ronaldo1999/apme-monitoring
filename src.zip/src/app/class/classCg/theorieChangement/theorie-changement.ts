export class TheorieChangement {
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    theoriechangementID!: string;
    code!: string;
    libelleFr!: string;
    libelleUs!: string;
    liens!: string;
    creation_date!: string;
    organisationID!: string;
}
