import { DialogueGestion } from './dialogue-gestion';

describe('DialogueGestion', () => {
  it('should create an instance', () => {
    expect(new DialogueGestion()).toBeTruthy();
  });
});
