export class Caneva {
    canevaID!: string;
    libelleFr!: string;
    libelleUs!: string;
    description!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    organisationID!: string;
    creation_date!: string;
}