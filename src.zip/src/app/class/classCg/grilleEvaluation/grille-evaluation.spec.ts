import { GrilleEvaluation } from './grille-evaluation';

describe('GrilleEvaluation', () => {
  it('should create an instance', () => {
    expect(new GrilleEvaluation()).toBeTruthy();
  });
});
