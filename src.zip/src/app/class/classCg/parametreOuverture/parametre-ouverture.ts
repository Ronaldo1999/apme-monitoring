import { CalendrierBudgetaire } from "../calendrierBudgetaire/calendrier-budgetaire";

export class ParametreOuverture {
    calendrierBudgetaireOrg!: CalendrierBudgetaire
    organisationIDs:string[]=[]
    all:boolean= false

}
