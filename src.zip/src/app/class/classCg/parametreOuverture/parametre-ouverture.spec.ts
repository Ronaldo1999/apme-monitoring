import { ParametreOuverture } from './parametre-ouverture';

describe('ParametreOuverture', () => {
  it('should create an instance', () => {
    expect(new ParametreOuverture()).toBeTruthy();
  });
});
