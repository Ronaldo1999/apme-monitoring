import { Activiterapportperiode } from './activiterapportperiode';

describe('Activiterapportperiode', () => {
  it('should create an instance', () => {
    expect(new Activiterapportperiode()).toBeTruthy();
  });
});
