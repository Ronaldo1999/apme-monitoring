export class Activiterapportperiode {
    
    periodeEvaluation!:string
    designation!:string
    bloque:any
    millesime!:string
    organisationID!:string
 
}
