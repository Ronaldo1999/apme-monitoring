export class Planstrat {
    planstratID!: string;
    libelleFr!: string;
    libelleUs!: string;
    description!: string;
    last_update!: string;
    ip_update!: string;
    user_update!: string;
    organisationID!: string;
    creation_date!: string;
    canevaID!: string;
}