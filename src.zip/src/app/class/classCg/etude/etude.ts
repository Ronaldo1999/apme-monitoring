export class Etude {
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    etudeID!: string;
    libelleFr!: string;
    libelleUs!: string;
    description!: string;
    projetID!: string;
    organisationID!: string;
    coutEstimatif!: number;
    date!: string;
    valide!: string;
    nbFinancement!: number;
    fichier!: boolean;
}
