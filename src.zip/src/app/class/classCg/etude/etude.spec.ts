import { Etude } from './etude';

describe('Etude', () => {
  it('should create an instance', () => {
    expect(new Etude()).toBeTruthy();
  });
});
