import { ActiviteGlobal } from './activite-global';

describe('ActiviteGlobal', () => {
  it('should create an instance', () => {
    expect(new ActiviteGlobal()).toBeTruthy();
  });
});
