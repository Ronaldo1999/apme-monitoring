import { Activite } from "../activite/activite";
import { ActiviteObjectif } from "../activiteObjectif/activite-objectif";

export class ActiviteGlobal {

    activite: Activite = new Activite()
    objectifs: ActiviteObjectif[] = []

}
