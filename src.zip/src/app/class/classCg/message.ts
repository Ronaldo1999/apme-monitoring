export class Message {
    id?:string;
    description?:string;
    categorie?:string;
    date?:string;
    image?:string;
}
