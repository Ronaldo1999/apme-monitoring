import { DialogueAction } from './dialogue-action';

describe('DialogueAction', () => {
  it('should create an instance', () => {
    expect(new DialogueAction()).toBeTruthy();
  });
});
