import { TableauMensuel } from './tableau-mensuel';

describe('TableauMensuel', () => {
  it('should create an instance', () => {
    expect(new TableauMensuel()).toBeTruthy();
  });
});
