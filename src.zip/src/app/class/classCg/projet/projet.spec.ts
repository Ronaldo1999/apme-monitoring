import { Projet } from './projet';

describe('Projet', () => {
  it('should create an instance', () => {
    expect(new Projet()).toBeTruthy();
  });
});
