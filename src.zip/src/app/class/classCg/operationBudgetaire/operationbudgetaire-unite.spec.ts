import { OperationbudgetaireUnite } from './operationbudgetaire-unite';

describe('OperationbudgetaireUnite', () => {
  it('should create an instance', () => {
    expect(new OperationbudgetaireUnite()).toBeTruthy();
  });
});
