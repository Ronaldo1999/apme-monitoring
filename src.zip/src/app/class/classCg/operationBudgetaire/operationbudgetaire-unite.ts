export class OperationbudgetaireUnite {
    code!:string
    compteCode!:string
    quantite!:number
    prixUnitaire!:number
    prixDeReference!:number
    numeroOrdre!:number
}
