import { OperationBudgetaire } from './operation-budgetaire';

describe('OperationBudgetaire', () => {
  it('should create an instance', () => {
    expect(new OperationBudgetaire()).toBeTruthy();
  });
});
