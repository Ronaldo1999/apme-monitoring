import { AnneeBudgetaire } from "../anneeBudgetaire/annee-budgetaire"

export class Calendrier {

    calendrierID!:string
    status!:boolean
    annees: AnneeBudgetaire[] =[]

}
