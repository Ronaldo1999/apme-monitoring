import { Calendrier } from './calendrier';

describe('Calendrier', () => {
  it('should create an instance', () => {
    expect(new Calendrier()).toBeTruthy();
  });
});
