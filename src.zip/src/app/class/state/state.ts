export class Stat {
    acteurs!: number;
    catproduits!: string;
    collectes!: string;
    export!: number;
    lv!: number;
    orproduits!: number;
    parties!: number;
    permis!: number;
    produits!: number;
    types!: number;
    familles!: number;
    unites!: number;
    catunites!: number;
}