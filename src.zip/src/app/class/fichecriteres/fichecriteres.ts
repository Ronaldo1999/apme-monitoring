export class Fichecriteres {

    last_update: any
    user_update: string = 'admin'
    ip_update: any
    idfichecriteres!: string
    idfichegroupe!: string
    libelleFr!: string
    libelleUs!: string
    libelleGroupe!: string
    valeur!: string
    mediocre: boolean = false
    moyen: boolean  = false
    suffisant: boolean  = false
    tresbien: boolean = false

   
}
