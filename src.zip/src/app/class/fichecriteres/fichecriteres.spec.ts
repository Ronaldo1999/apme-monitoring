import { Fichecriteres } from './fichecriteres';

describe('Fichecriteres', () => {
  it('should create an instance', () => {
    expect(new Fichecriteres()).toBeTruthy();
  });
});
