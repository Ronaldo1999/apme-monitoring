export class Ue {

    id!:number
    codeu!:string;
    nomue!:string;
    coefficient!:number
    prerequis!: string;
    objectifs!: string;
    cout!: number;
    idgue!: number;
    seances!: number;
}
