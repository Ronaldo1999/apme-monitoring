import { Ue } from './ue';

describe('Ue', () => {
  it('should create an instance', () => {
    expect(new Ue()).toBeTruthy();
  });
});
