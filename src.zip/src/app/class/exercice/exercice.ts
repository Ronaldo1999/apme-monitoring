export class Exercice {
    millesime!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    libelleFr!: string;
    libelleUs!: string;
    dateDebut!: Date;
    dateFin!: Date;
    enProgrammation!: boolean;
    enBudgetisation!: boolean;
    enExecution!: boolean;
    enCloture!: boolean;
    userupdate!: string;
    ipupdate!: string;
}
