import { Exercice } from './exercice';

describe('Exercice', () => {
  it('should create an instance', () => {
    expect(new Exercice()).toBeTruthy();
  });
});
