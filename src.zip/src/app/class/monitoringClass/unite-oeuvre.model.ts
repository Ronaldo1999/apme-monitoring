export class MoUniteOeuvre {
    moUniteOeuvreID!: string;
    designation!: string;
    conditionnement!: string;
    prixunitaire!: number;
    typeunite!: number;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    created_at!: string;
    created_by!: string;
    organisationID!: string;
    millesime!: string;
}