export class ActiviteARealiserSuivi {
    moniActiviteARealiserID!: string;
    moPlanTravailID!: string;
    structureID!: string;
    spID!: string;
    actionID!: string;
    activiteID!: string;
    tacheID!: string;
    dateDebut!: string;
    dateFin!: string;
    raciID!: string;
    modeContractualisation!: string;
    reference!: string;
    cible!: string;
    poids!: string;
    taux!: string;
    echeance!: string;
    cout!: string;
    statut!: string;
    offline!: string;
    frequence!: string;
    libelleFr!: string;
    libelleUs!: string;
    organisationID!: string;
    millesime!: string;
    description!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    created_at!: string;
    created_by!: string;
    derniereReference!: string;
    derniereCible!: string;
    ancientaux!: string;
    moniActiviteARealiserSuiviID!: string;

}