export class MoPointFocaleStructure {
    moPointFocaleStructureID!: string;
    moPointFocaleID!: string;
    structureID!: string;
    organisationID!: string;
    millesime!: string;
    description!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    created_at!: string;
    created_by!: string;

}