export class MoMemoireDepense{
    moMemoireDepenseID!: string;
    moUniteOeuvreID!: string;
    moniActiviteARealiserID!: string;
    quantite: number = 1;
    montant: number = 1;
    prixunitaire!: number;
    designation!: string;
    conditionnement!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    created_at!: string;
    created_by!: string;
    organisationID!: string;
    millesime!: string;
}