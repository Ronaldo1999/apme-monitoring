import { ActiviteARealiser } from "./activitearealiser.model";

export class PlanTravail {
    moPlanTravailID!: string;
    libelleFr!: string;
    libelleUs!: string;
    organisationID!: string;
    structureID!: string;
    mode!: number;
    millesime!: string;
    description!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    moPointFocaleID!: string;
    created_at!: string;
    created_by!: string;

    activiteARealisers: ActiviteARealiser[] = [];
    structureplans: PlanStructure[] = [];
}

export class PlanStructure {
    moPlanTravailID!: string;
    organisationID!: string;
    structureID!: string;
    millesime!: string;
    last_update!: string;
    user_update!: string;
    ip_update!: string;
    created_at!: string;
    created_by!: string;
}