export class UpdateState {
  elementID!: any;
  elementSID!: any;
  user_update!: string;
  ip_update!: string;
  action!: number;
  typeID!: number;
}
