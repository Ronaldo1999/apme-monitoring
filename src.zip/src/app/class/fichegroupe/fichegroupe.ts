export class Fichegroupe {
    last_update: any
    user_update: string = 'admin'
    ip_update: any
    idfichegroupe!: string
    libelleFr!: string
    libelleUs!: string
}
