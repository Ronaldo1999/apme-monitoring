import { Fichegroupe } from './fichegroupe';

describe('Fichegroupe', () => {
  it('should create an instance', () => {
    expect(new Fichegroupe()).toBeTruthy();
  });
});
