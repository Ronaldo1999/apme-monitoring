export class ResponseFile {
     id: string = '';
     name?: string;
     oldname?: string;
     url?: string;
     type?: string;
     size?: number;
     data: any
     user_update!: string;
     ipupdate!: string;
     prive?: number
}
