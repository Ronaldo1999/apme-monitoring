export class Salle {

    id!: number
    codeSalle!:string
    nom!:string


}
