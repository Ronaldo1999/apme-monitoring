export enum ModeContractualisation {
    BCA = 'BCA',
    MARCHE = 'MARCHE',
    MISSION = 'MISSION'
}