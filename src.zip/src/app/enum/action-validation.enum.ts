export enum ActionValidation {
    enetude = 0,
    enentretien = 10,
    encontractualisation = 20,
    retenue = 30,
    validationCandidature = 20,
    annulationCandidature = 10,
}