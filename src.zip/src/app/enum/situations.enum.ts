export enum SituationFamiliale {
    MARIE = "MARIE",
    CELIBATAIRE = "CELIBATAIRE",
    DIVORCE = "DIVORCE",
    VEUF_VEUVE = "VEUF_VEUVE",
}