export enum TypeEtape {
    ANNONCE = 'ANNONCE',
    COLLECTE = 'COLLECTE',
    EXAMEN = 'EXAMEN',
    ENTRETIEN = 'ENTRETIEN',
    ANALYSE = 'ANALYSE',
}