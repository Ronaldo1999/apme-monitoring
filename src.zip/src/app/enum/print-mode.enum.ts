export enum PrintMode {
    activite = "activite",
    planaction = "planaction",
   
}