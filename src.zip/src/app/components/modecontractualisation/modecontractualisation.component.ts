import { Component } from '@angular/core';

@Component({
  selector: 'app-modecontractualisation',
  templateUrl: './modecontractualisation.component.html',
  styleUrls: ['./modecontractualisation.component.scss']
})
export class ModecontractualisationComponent {

}
