import { NumberInputDirectiveDirective } from './number-input-directive.directive';

describe('NumberInputDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new NumberInputDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
