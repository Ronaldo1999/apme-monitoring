import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TreeNode } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { TokenStorageService } from 'src/app/auth/_services/token-storage.service';
import { Structure } from 'src/app/class/class/structure/structure';
import { Activite } from 'src/app/class/classCg/activite/activite';
import { ActiviteParametre } from 'src/app/class/classCg/activiteParametre/activite-parametre';
import { FactAgent } from 'src/app/class/classCg/gestFacture/facture';
import { Exercice } from 'src/app/class/exercice/exercice';
import { FindParam } from 'src/app/class/find-param';
import { ActiviteARealiser } from 'src/app/class/monitoringClass/activitearealiser.model';
import { MoIndicateur } from 'src/app/class/monitoringClass/indicateur.model';
import { MoMemoireDepense } from 'src/app/class/monitoringClass/memoire-depense.model';
import { MoOperation, MoOperationCompte } from 'src/app/class/monitoringClass/operation.model';
import { PlanStructure, PlanTravail } from 'src/app/class/monitoringClass/plantravail.model';
import { MoPointFocale } from 'src/app/class/monitoringClass/pointfocale';
import { MoUniteOeuvre } from 'src/app/class/monitoringClass/unite-oeuvre.model';
import { Organisation } from 'src/app/class/organisation/organisation';
import { Action } from 'src/app/enum/action.enum';
import { ModeContractualisation } from 'src/app/enum/mode-contractualisation.enum';
import { ApiService } from 'src/app/services/apiBase.service';
import { formatDate } from '@angular/common';

import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable'
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NumberFormatter } from './number-formatter'; // Assurez-vous d'utiliser le bon chemin  


@Component({
  selector: 'app-elaboration',
  templateUrl: './elaboration.component.html',
  styleUrls: ['./elaboration.component.scss']
})
export class ElaborationComponent implements OnInit {
  fparam: any;
  options: any[] = [];
  action = '';
  libelleRec = '';
  organisation: Organisation = new Organisation();
  organisations: Organisation[] = [];
  exercice: Exercice = new Exercice();
  exercices: Exercice[] = [];
  structures: Structure[] = [];

  activitesAll: Activite[] = [];
  activite: Activite = new Activite();
  taches: Activite[] = [];
  param = new ActiviteParametre();
  objectifs: any[] = [];

  displaySpinner = false;

  structure: Structure = new Structure();
  sousprogrammes: Activite[] = [];
  actions: Activite[] = [];
  activites: Activite[] = [];
  indicateurs: MoIndicateur[] = [];


  planactions: any[] = [];
  selectedPa = new PlanTravail();
  droits: any[] = [];
  username!: string;

  pageByAction = Action.LIST;

  comptes: MoOperationCompte[] = [];
  selectedComptes: MoOperationCompte[] = [];
  selectedActivites: any[] = [];

  pf: MoPointFocale = new MoPointFocale();

  agents: FactAgent[] = [];
  arbre: TreeNode[] = [];
  selectedNodes: TreeNode[] = [];

  arbre2: TreeNode[] = [];
  arbre3: TreeNode[] = [];

  defaultText: string = "Drop documents to upload";
  dropText: string = "Drop documents to upload";
  fileTypeError: boolean = false;
  pdfUrl: SafeResourceUrl | null = null; // URL sécurisée pour l'iframe
  fileUploaded: boolean = false; // État du fichier téléchargé
  uploadProgress: number = 0; // Progression du téléchargement
  uploadedFile: File | null = null; // Propriété pour stocker le fichier

  @ViewChild('fileInput') fileInput!: ElementRef;

  stplan: PlanStructure = new PlanStructure();
  structureplans: string[] = [];
  constructor(
    private api: ApiService,
    private cgApi: ApiService,
    private ts: TokenStorageService,
    public translate: TranslateService,
    private sanitizer: DomSanitizer,
    public dialogService: DialogService) {
    this.getOrganisation();
    this.fparam = new FindParam(this.ts.getOrganisation(), this.ts.getUser().username);
    this.droits = this.ts.getRoles();
    this.username = this.ts.getUser().username;
  }

  ngOnInit() {
    this.listOrganisation();
    this.listExercice();
  }

  getOrg(organisationID: string) {
    for (const ele of this.organisations) {
      if (ele.organisationID == organisationID) {
        this.organisation = ele;
      }
    }
  }

  listActivs: Activite[] = [];
  activitesAR: ActiviteARealiser[] = [];
  operations: MoOperation[] = [];
  depenses: MoMemoireDepense[] = [];
  selectedOperations: MoOperation[] = [];
  operationsAR: MoOperation[] = [];
  operationAR: MoOperation = new MoOperation();
  listActivite(organisationID: string, millesime: string) {
    this.activitesAll = [];
    this.api.activiteList(organisationID, millesime, this.ts.getUser().username).subscribe((res) => {
      console.log(res);
      this.activitesAll = res;
      this.sousprogrammes = res.filter((activite: Activite) => activite.niveauActiviteID === 1);
      console.log(this.activitesAll);
    });
  }

  createDep() {

  }

  listAR(tache: Activite) {
    this.activite = tache;
    this.fparam.organisationID = this.organisation.organisationID;
    this.fparam.millesime = this.exercice.millesime;
    this.fparam.activiteID = tache.activiteParentID;
    this.fparam.tacheID = tache.activiteID;
    this.fparam.structureID = this.pa.structureID;
    this.fparam.moPlanTravailID = this.pa.moPlanTravailID;
    this.displaySpinner = true;
    this.activitesAR = []; console.log(this.fparam);
    this.api.listMoActiviteARealiser(this.fparam).subscribe((res) => {
      console.log(res);
      this.activitesAR = res;
      console.log(this.activitesAR);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }
  filtrer(tache: Activite) {
    this.activite = tache;
    this.fparam.organisationID = this.organisation.organisationID;
    this.fparam.millesime = this.exercice.millesime;
    this.fparam.activiteID = tache.activiteParentID;
    this.fparam.tacheID = tache.activiteID;
    this.fparam.structureID = this.pa.structureID;
    this.fparam.moPlanTravailID = this.pa.moPlanTravailID;
    if (this.fparam.organisationID && this.fparam.millesime && this.fparam.activiteID && this.fparam.tacheID && this.fparam.structureID && this.fparam.moPlanTravailID) {
      this.displaySpinner = true;
      this.activitesAR = [];
      this.api.listMoActiviteARealiser(this.fparam).subscribe((res) => {
        console.log(res);
        this.activitesAR = res;
        console.log(this.activitesAR);
        this.displaySpinner = false;
      }, error => {
        this.displaySpinner = false;
      });
    } else if (this.fparam.organisationID && this.fparam.millesime && this.fparam.structureID && this.fparam.moPlanTravailID) {
      this.displaySpinner = true;
      this.activitesAR = [];
      this.api.listMoActiviteARealiserAll(this.fparam).subscribe((res) => {
        console.log(res);
        this.activitesAR = res;
        console.log(this.activitesAR);
        this.displaySpinner = false;
      }, error => {
        this.displaySpinner = false;
      });
    }
  }



  async listMoActiviteARealiserAll(moPlanTravailID: string) {
    this.fparam.organisationID = this.organisation.organisationID;
    this.fparam.millesime = this.exercice.millesime;
    this.fparam.structureID = this.structure.structureID;
    this.fparam.moPlanTravailID = moPlanTravailID;
    if (this.fparam.organisationID && this.fparam.millesime && moPlanTravailID && this.fparam.structureID) {
      this.displaySpinner = true;
      this.activitesAR = await this.cgApi.listMoActiviteARealiserAll(this.fparam).toPromise();
      this.displaySpinner = false;
    }
  }


  getActiviteByID(activiteID: string, tab: Activite[]) { let act = new Activite(); for (const ele of tab) { if (ele.activiteID === activiteID) { act = ele; } } return act; }
  convertAR(tache?: Activite) {
    this.activiteAR = new ActiviteARealiser();
    if (tache) {
      this.activiteAR.tacheID = tache.activiteID;
      this.activiteAR.activiteID = tache.activiteParentID;
      this.activiteAR.libelleFr = tache.libelleFr;
      this.activiteAR.libelleUs = tache.libelleUs;
      this.activiteAR.reference = tache.reference;
      this.activiteAR.cible = tache.cible;
      this.activiteAR.poids = tache.poids;
      this.activiteAR.cout = tache.cout;
      this.onSelectTache(tache.activiteID);
    }
    this.actionPA = 'editPA';
    this.activiteAR.moPlanTravailID = this.pa.moPlanTravailID;
    this.listMoActiviteARealiserAll(this.pa.moPlanTravailID);
    this.activiteAR.moniActiviteARealiserID = `MOAC${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
    this.getPageByAction(Action.CREATEAR);
  }
  clearFilter() {
    this.activiteManip = new ActiviteARealiser();
  }
  activiteARDialog = false;
  paDialog = false;
  pa: PlanTravail = new PlanTravail();
  activiteAR: ActiviteARealiser = new ActiviteARealiser();
  activiteManip: ActiviteARealiser = new ActiviteARealiser();
  operation: MoOperation = new MoOperation();
  opcompte: MoOperationCompte = new MoOperationCompte();
  actionPA = 'newPA';
  actionAR = 'newAR';
  actionOP = 'newOP';
  acte = 1;
  create() {
    this.removeFile();
    this.acte = 1;
    this.actionPA = 'newPA';
    this.pa = new PlanTravail();
    this.init();
    this.pa.mode = 2;
    this.pa.moPlanTravailID = `MOPA${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
    this.getPageByAction(Action.CREATEPA);
  }
  uploadPA() {
    this.removeFile();
    this.acte = 1;
    this.actionPA = 'newPA';
    this.pa = new PlanTravail();
    this.init();
    this.pa.mode = 1;
    this.pa.moPlanTravailID = `MOPA${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
    this.getPageByAction(Action.UPLOADPA);
  }
  wit = false;

  createAR(tache?: Activite) {
    this.operations = [];
    if (tache) {
      this.wit = false;
      this.activite = tache;
      this.activiteAR.tacheID = tache.activiteID;
      this.onSelectTache(tache.activiteID);
      this.activiteAR.activiteID = tache.activiteParentID;
    } else { this.wit = true; }
    this.acte = 2;
    this.activiteAR = new ActiviteARealiser();
    this.actionPA = 'editPA';
    this.activiteAR.moPlanTravailID = this.pa.moPlanTravailID;
    this.activiteAR.moniActiviteARealiserID = `MOAC${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
    this.getPageByAction(Action.CREATEAR);
  }
  operationDialog = false;
  createOP() {
    this.actionOP = 'newOP';
    this.action = 'new';
    this.acte = 3;
    this.operation = new MoOperation();
    this.comptes = [];
    this.depenses = [];
    this.operation.moniActiviteARealiserID = this.activiteAR.moniActiviteARealiserID;
    this.operation.moOperationID = `MOOP${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
    this.listUo();
    this.getPageByAction(Action.CREATEOP);//this.operationDialog = true;
  }
  /*  createOP() {
     this.action = 'new';
     this.acte = 3;
     this.operation = new MoOperation();
     this.operation.moniActiviteARealiserID = this.activiteAR.moniActiviteARealiserID;
     this.operation.moOperationID = `MOOP${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
     this.getPageByAction(Action.CREATEOP);
   } */

  getPA(pa: PlanTravail, action: string) {
    this.action = action;
    this.pa = { ...pa };
    this.acte = 1;
    this.actionPA = action + 'PA';
    this.init();
    this.listMoActivite(pa.structureID, 'prem', 1);
    this.getPageByAction(Action.CREATEPA);
    this.listAgent();
  }
  getAR(activiteAR: ActiviteARealiser, action: string) {
    console.log(activiteAR);
    this.wit = false;
    this.activiteAR = { ...activiteAR };
    this.acte = 2;
    this.actionAR = action + 'AR';
    this.opcompte = new MoOperationCompte();
    this.listOperation(activiteAR);
    this.onSelectTache(activiteAR.tacheID);
    this.getPageByAction(Action.CREATEAR);
    if (activiteAR.typer == 1 && activiteAR.r) {
      this.selectedAR = JSON.parse(activiteAR.r);
    } else {
      this.selectedStrR = JSON.parse(activiteAR.r);
    }
    if (activiteAR.typea == 1 && activiteAR.a) { this.selectedAA = JSON.parse(activiteAR.a); } else { this.selectedStrA = JSON.parse(activiteAR.a); }
    if (activiteAR.typec == 1 && activiteAR.c) { this.selectedAC = JSON.parse(activiteAR.c); } else { this.selectedStrC = JSON.parse(activiteAR.c); }
    if (activiteAR.typei == 1 && activiteAR.i) { this.selectedAI = JSON.parse(activiteAR.i); } else { this.selectedStrI = JSON.parse(activiteAR.i); }
  }
  getOP(operation: MoOperation, action: string) {
    this.operation = { ...operation };
    this.acte = 3;
    this.actionOP = action + 'OP';
    this.listUo();
    this.listMoOperationComptes(operation);
    this.listMoMemoireDepense(operation);
    this.getPageByAction(Action.CREATEOP); //this.operationDialog = true;
  }
  structureList(organisationID: string) {
    this.displaySpinner = true;
    this.structures = [];
    this.api.structureList('fr', organisationID).subscribe((data) => {
      this.structures = data;
      console.log(data);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }


  back(niveau: number) {
    this.acte = niveau;
    switch (niveau) {
      case 1: this.getPageByAction(Action.CREATEPA); break;
      case 2: this.getPageByAction(Action.CREATEAR); break;
      case 3: this.getPageByAction(Action.CREATEOP); break;
      default:
        break;
    }
  }
  getOC(opcompte: MoOperationCompte) {
    this.opcompte = { ...opcompte };
  }
  getMemoire(momemoire: MoMemoireDepense) {
    this.depense = { ...momemoire };
  }
  deleteDialog = false;
  deleteOp(operation: MoOperation) {
    this.operation = { ...operation };
    this.deleteDialog = true;
    this.srca = 'assets/img/attention.png';
  }

  supprimer() { }



  async onSelectActivite(activiteID: string) {
    if (this.getActiviteByID(activiteID, this.activitesAll).niveauActiviteID != 4) {
      switch (this.getActiviteByID(activiteID, this.activitesAll).niveauActiviteID) {
        case 1: this.actions = []; this.activites = []; this.taches = []; break;
        case 2: this.activites = []; this.taches = []; break;
        case 3: this.taches = []; this.comptebudgetaire = []; break;
        case 3: this.taches = []; break;
        default:
          break;
      }

      this.api.listMoActivite(this.organisation.organisationID, this.exercice.millesime, this.structure.structureID, this.getActiviteByID(activiteID, this.activitesAll).activiteID, this.getActiviteByID(activiteID, this.activitesAll).niveauActiviteID + 1).subscribe((data) => {
        console.log(data);
        this.activitesAll = data;
        for (const ele of data) {
          switch (ele.niveauActiviteID) {
            case 2: this.actions.push(Object.assign({}, ele)); break;
            case 3: this.activites.push(Object.assign({}, ele)); break;
            case 4: this.taches.push(Object.assign({}, ele)); break;
            default:
              break;
          }
        }
      })
    } else {
      this.onSelectTache(activiteID);
    }

  }

  montantMax = 0;

  removeCompte(i: number) {
    this.comptes.splice(i, 1);
  }
  removeDepense(i: number) {
    this.depenses.splice(i, 1);
  }
  addOperationComp() {

    this.opcompte.moOperationCompteID = `MOOPC${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
    this.comptes.push(this.opcompte);
    this.opcompte = new MoOperationCompte();
  }
  selectedStrR: string[] = [];
  selectedStrA: string[] = [];
  selectedStrC: string[] = [];
  selectedStrI: string[] = [];
  selectedAR: string[] = [];
  selectedAA: string[] = [];
  selectedAC: string[] = [];
  selectedAI: string[] = [];

  comptebudgetaire: any[] = [];
  onSelectTache(tacheID: string) {
    this.filtrer(this.activite);
    this.displaySpinner = true;
    this.comptebudgetaire = [];
    this.api.listCompteOperation(tacheID, this.structure.structureID).subscribe((res) => {
      this.comptebudgetaire = res;
      console.log(res);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }

  createIndicateur() {

  }

  getMongo(a: Activite) {
    console.log(a);
    this.getChildActivities(a);
  }

  /* getChildActivities(a: Activite): Activite[] {
    return this.activitesAll.filter((activite) => activite.niveauActiviteID === a.niveauActiviteID + 1 && activite.activiteParentID === a.activiteID);
  } */

  loading = false;
  async getChildActivities(a: Activite) {
    this.loading = true;
    if (a.niveauActiviteID != 4) {
      switch (a.niveauActiviteID) {
        case 1: this.actions = []; this.activites = []; this.taches = []; this.activitesAR = []; break;
        case 2: this.activites = []; this.taches = []; this.activitesAR = []; break;
        case 3: this.taches = []; this.activitesAR = []; break;
        case 4: this.activitesAR = []; break;
        default:
          break;
      }
      this.api.listMoActivite(this.organisation.organisationID, this.exercice.millesime, this.structure.structureID, a.activiteID, a.niveauActiviteID + 1).subscribe((data) => {
        console.log(data);
        this.activitesAll = data;
        for (const ele of data) {
          switch (ele.niveauActiviteID) {
            case 2: this.actions.push(Object.assign({}, ele)); break;
            case 3: this.activites.push(Object.assign({}, ele)); break;
            case 4: this.taches.push(Object.assign({}, ele)); break;
            default:
              break;
          }
        }
        for (const element of data) { element.color = "#767676"; element.visibilte = "hidden"; }
        for (const element of data) { if (element.activiteID == a.activiteID) { element.color = "#0066FF"; element.visibilte = "visible"; } }
      })
    } else {
      this.onSelectTache(a.activiteID);
    }
    this.loading = false;
  }


  getList() {
    this.getPageByAction(Action.LIST);
  }
  getPageByAction(action: Action) { this.pageByAction = action; }
  getOrganisation() { this.organisation.organisationID = this.ts.getOrganisation(); }
  listOrganisation() { this.api.organisationList('', true).subscribe((data) => { console.log(data); this.organisations = data; if (data.length == 1) { this.organisation = data[0]; } }); }

  listExercice() {
    this.displaySpinner = true;
    this.api.listExercice().subscribe((data) => {
      console.log(data); this.exercices = data;
      this.displaySpinner = false;
      this.exercice = data[data.length - 1];
    }, error => {
      this.displaySpinner = false;
    });
  }

  load() { this.listPlan(this.structure.structureID); }
  onDropdown1(pa: PlanTravail) {
    this.pa = pa;
    this.options = [
      { label: "Consulter", icon: 'fas fa-eye', color: 'rgb(23, 74, 125)', command: () => { this.getPA(pa, 'view') } },
      { label: 'Modifier', icon: 'fas fa-edit', color: 'rgb(23, 74, 125)', command: () => { this.getPA(pa, 'edit') } },
      { label: "Transmettre pour validation", icon: 'fas fa-share', color: 'rgb(23, 74, 125)', command: () => { } },
      { label: "Valider le plan d'action", icon: 'fas fa-check-square', color: 'rgb(23, 74, 125)', command: () => { } },
      { label: "Exporter le plan d'action en word", icon: 'fas fa-print', color: 'rgb(23, 74, 125)', command: () => { } },
      { separator: true },
      { label: "Supprimer", icon: 'fas fa-trash', pTooltip: "Actions groupés", color: '#ce2727', command: () => { } },
    ];
  }
  onDropdown(activite: ActiviteARealiser) {
    if (activite.moniActiviteARealiserID) {
      this.activiteAR = activite;
      this.options = [
        { label: "Consulter", icon: 'fas fa-eye', color: 'rgb(23, 74, 125)', command: () => { this.getAR(activite, 'view') } },
        { label: 'Modifier', icon: 'fas fa-edit', color: 'rgb(23, 74, 125)', command: () => { this.getAR(activite, 'edit') } },
        { label: "Nouvelle opération", icon: 'fas fa-folder-plus', color: 'rgb(23, 74, 125)', command: () => { this.createOP() } },
        { label: "Envoyer au RACI concerné", icon: 'fas fa-share', color: 'rgb(23, 74, 125)', command: () => { } },
        { label: "Valider le l'activité", icon: 'fas fa-check-square', color: 'rgb(23, 74, 125)', command: () => { } },
        { label: "Convertir les comptes en opérations", icon: 'fas fa-check-square', color: 'rgb(23, 74, 125)', command: () => { this.convertCompteToOp(activite) } },
        { separator: true },
        { label: "Supprimer", icon: 'fas fa-trash', pTooltip: "Actions groupés", color: '#ce2727', command: () => { } },
      ];
    }
  }
  onDropdownOP(element: MoOperation) {
    this.operationAR = element;
    this.options = [
      { label: "Consulter", icon: 'fas fa-eye', color: 'rgb(23, 74, 125)', command: () => { this.getOP(element, 'view') } },
      { label: 'Modifier', icon: 'fas fa-edit', color: 'rgb(23, 74, 125)', command: () => { this.getOP(element, 'edit') } },
      { label: "Nouvel indicateur", icon: 'fas fa-folder-plus', color: 'rgb(23, 74, 125)', command: () => { } },
      { label: "Envoyer au RACI concerné", icon: 'fas fa-share', color: 'rgb(23, 74, 125)', command: () => { } },
      { label: "Valider le l'activité", icon: 'fas fa-check-square', color: 'rgb(23, 74, 125)', command: () => { } },
      { separator: true },
      { label: "Supprimer", icon: 'fas fa-trash', pTooltip: "Actions groupés", color: '#ce2727', command: () => { } },
    ];
  }

  onDropdownARList() {
    this.options = [
      { label: "Envoyer au RACI concerné", icon: 'fas fa-share', color: 'rgb(23, 74, 125)', command: () => { } },
      { label: "Valider les activités", icon: 'fas fa-check-square', color: 'rgb(23, 74, 125)', command: () => { } },
      { separator: true },
      { label: "Supprimer", icon: 'fas fa-trash', pTooltip: "Actions groupés", color: '#ce2727', command: () => { } },
    ];
  }
  onDropdownOPList() {
    this.options = [
      { label: "Envoyer au RACI concerné", icon: 'fas fa-share', color: 'rgb(23, 74, 125)', command: () => { } },
      { label: "Valider les opérations", icon: 'fas fa-check-square', color: 'rgb(23, 74, 125)', command: () => { } },
      { separator: true },
      { label: "Supprimer", icon: 'fas fa-trash', pTooltip: "Actions groupés", color: '#ce2727', command: () => { } },
    ];
  }

  onCheckboxChange(id: string, isChecked: boolean) {
    if (isChecked) { this.selectedActivites.push(id); } else {
      const index = this.selectedActivites.indexOf(id);
      if (index !== -1) { this.selectedActivites.splice(index, 1); }
    }
  }
  clearResearch() {
    this.libelleRec = '';

  }
  libelleSpinner = 'operationEnCOurs'
  convertCompteToOp(activite: ActiviteARealiser) {
    this.displaySpinner = true;
    this.libelleSpinner = 'convertionEnCOurs';

    this.api.findCompte(activite.tacheID, this.structure.structureID).subscribe((res) => {
      this.comptebudgetaire = res;
      console.log(res);
      const saveOperationsPromises = res.map((ele: any) => {
        let operation = new MoOperation();
        operation.montant = ele.cp;
        operation.libelleFr = ele.libelleFr;
        operation.libelleUs = ele.libelleUs;
        operation.indicateur = "Pas d'indicateurs";
        operation.objectif = "Pas d'indicateurs";
        operation.organisationID = this.organisation.organisationID;
        operation.structureID = this.structure.structureID;
        operation.millesime = this.exercice.millesime;
        operation.user_update = this.ts.getUser().username;
        operation.moniActiviteARealiserID = activite.moniActiviteARealiserID;
        operation.ip_update = '127.0.0.1';
        operation.moOperationID = `MOOP${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
        const opeOmpte = new MoOperationCompte();
        opeOmpte.montant = ele.cp;
        opeOmpte.operationBudgetaireID = ele.tacheID;
        opeOmpte.libelleFr = ele.compteCode + ' - ' + ele.libelleFr;
        opeOmpte.libelleUs = ele.compteCode + ' - ' + ele.libelleUs;
        opeOmpte.moOperationCompteID = `MOOPC${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
        console.log(opeOmpte);
        operation.operationComptes.push(Object.assign({}, opeOmpte));
        console.log(operation);
        return this.api.saveOperation(operation).toPromise();
      });

      Promise.all(saveOperationsPromises)
        .then(() => {
          this.succes("successSaveOperations");
          this.listOperation(activite);

        })
        .catch(error => {
          this.erreur("errorSaveOperations");
          console.error(error);
        })
        .finally(() => {
          this.displaySpinner = false;
          this.libelleSpinner = 'Chargement';
        });

      console.log(res);
    }, error => {
      this.displaySpinner = false;
    });
  }


  listCompte(organisationID: string, millesime: string) {
    this.api.compteList(organisationID, millesime, this.ts.getUser().username).subscribe((data) => {
      this.comptes = data; console.log(data);
    })
  }
  listSTructureByPf(moPointFocaleID: string) {
    this.displaySpinner = true;
    this.api.listPlanAll(this.organisation.organisationID, this.exercice.millesime, moPointFocaleID).subscribe((data) => {
      this.planactions = data; console.log(data);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    })
    this.api.listSTructureByPf(this.organisation.organisationID, moPointFocaleID).subscribe((data) => {
      this.structures = data;
      console.log(data);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }
  listPlan(structureID: string) {
    if (structureID) {
      // this.listMoActivite(structureID, 'prem', 1);
      this.displaySpinner = true;
      console.log(this.pf.moPointFocaleID);
      this.api.listPlan(this.organisation.organisationID, this.exercice.millesime, this.pf.moPointFocaleID, structureID).subscribe((data) => {
        this.planactions = data; console.log(data);
        this.displaySpinner = false;
      }, error => {
        this.displaySpinner = false;
      })
    } else {
      this.api.listPlanAll(this.organisation.organisationID, this.exercice.millesime, this.pf.moPointFocaleID).subscribe((data) => {
        this.planactions = data; console.log(data);
        this.displaySpinner = false;
      }, error => {
        this.displaySpinner = false;
      })
    }

  }

  getStr(structureID: string) {
    let structure: Structure = new Structure();
    for (const ele of this.structures) {
      if (ele.structureID === structureID) {
        structure = ele;
      }
    }
    return structure;
  }
  async listMoActivite(structureID: string, activiteParentID: string, niveau: number) {
    this.structure.structureID = structureID;
    this.sousprogrammes = [];
    this.activitesAll = [];
    this.arbre = [];
    var arrayToTree = require('array-to-tree');
    this.displaySpinner = true;
    this.api.listMoActivite(this.organisation.organisationID, this.exercice.millesime, structureID, activiteParentID, niveau).subscribe(async (data) => {
      this.activitesAll = data; console.log(data);
      this.sousprogrammes = data.filter((activite: Activite) => activite.niveauActiviteID === 1);
      console.log(data);
      for (let item of data) {
        let file: TreeNode = { key: "", data: null, parent: undefined, children: [{ data: {} }] };
        file.key = item.activiteID;
        file.data = item;
        file.parent = item.activiteParentID;
        this.arbre.push(file);
      };
      // convertir le tableau de treeNode en arbre
      this.arbre = arrayToTree(this.arbre, {
        parentProperty: 'parent',
        customID: 'key'
      });
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }




  close() {
    this.getPageByAction(Action.LIST);
  }

  init() {
    this.arbre = [];
    this.arbre2 = [];
    this.arbre3 = [];
    this.sousprogrammes = [];
    this.actions = [];
    this.activites = [];
    this.taches = [];
    this.activitesAR = [];
    this.operations = [];
  }

  clear(a: Activite) {
    switch (a.niveauActiviteID) {
      case 1: this.actions = []; this.activites = []; this.taches = []; this.activitesAR = []; break;
      case 2: this.activites = []; this.taches = []; this.activitesAR = []; break;
      case 3: this.taches = []; this.activitesAR = []; break;
      case 4: this.activitesAR = []; break;
      default:
        break;
    }
  }
  clearAR() {
    this.operations = [];
  }

  itMyChildAction(a: Activite) {
    let res = false;
    if (this.actions.length) {
      for (const ele of this.actions) {
        if (ele.activiteParentID == a.activiteID) {
          res = true;
        }
      }
    }
    return res;
  }
  itMyChildActivite(a: Activite) {
    let res = false;
    if (this.activites.length) {
      for (const ele of this.activites) {
        if (ele.activiteParentID == a.activiteID) {
          res = true;
        }
      }
    }
    return res;
  }
  itMyChildTaches(a: Activite) {
    let res = false;
    if (this.taches.length) {
      for (const ele of this.taches) {
        if (ele.activiteParentID == a.activiteID) {
          res = true;
        }
      }
    }
    return res;
  }

  itMyChildAR(a: Activite) {
    let res = false;
    if (this.activitesAR.length) {
      for (const ele of this.activitesAR) {
        if (ele.tacheID == a.activiteID) {
          res = true;
        }
      }
    }
    return res;
  }
  itMyChildOp(a: ActiviteARealiser) {
    let res = false;
    if (this.operations.length) {
      for (const ele of this.operations) {
        if (ele.moniActiviteARealiserID == a.moniActiviteARealiserID) {
          res = true;
        }
      }
    }
    return res;
  }
  itMyAR(a: Activite) {
    let res = false;
    if (this.activitesAR.length) {
      for (const ele of this.activitesAR) {
        if (ele.tacheID == a.activiteID) {
          res = true;
        }
      }
    }
    return res;
  }
  itMy(a: Activite) {
    let res = false;
    if (this.actions.length) {
      for (const ele of this.actions) {
        if (ele.activiteParentID == a.activiteID) {
          res = true;
        }
      }
    }

    return res;
  }

  mouseUp(activi: ActiviteARealiser) { for (const activ of this.activitesAR) { if (activ.moniActiviteARealiserID == activi.moniActiviteARealiserID && activ.color == "#0066FF") { activ.color = "#767676"; activi.color = "#767676"; activi.visibilte = "hidden"; } else { activi.color = "#767676"; activi.visibilte = "hidden"; } } }
  decoloreAncien(activi: ActiviteARealiser) { for (const activ of this.activitesAR) { if (activ.moniActiviteARealiserID != activi.moniActiviteARealiserID && activ.color == "#0066FF") { activ.color = "#767676"; activ.visibilte = "hidden"; activi.color = "#0066FF"; activi.visibilte = "visible"; } else { activi.color = "#0066FF"; activi.visibilte = "visible"; } } }
  changeColor(activ: ActiviteARealiser) { this.activiteAR = activ; for (const activ of this.activitesAR) { if (activ.moniActiviteARealiserID == activ.moniActiviteARealiserID) { this.decoloreAncien(activ); } } }

  changeColorOP(operation: MoOperation) { this.operation = operation; for (const ope of this.operationsAR) { if (ope.moOperationID == operation.moOperationID) { this.decoloreAncienOP(ope); } } }
  decoloreAncienOP(opera: MoOperation) { for (const operation of this.operationsAR) { if (operation.moOperationID != opera.moOperationID && operation.color == "#0066FF") { operation.color = "#767676"; operation.visibilte = "hidden"; opera.color = "#0066FF"; opera.visibilte = "visible"; } else { opera.color = "#0066FF"; opera.visibilte = "visible"; } } }
  mouseUpOP(ope: MoOperation) { for (const oper of this.operationsAR) { if (oper.moOperationID == ope.moOperationID && oper.color == "#0066FF") { oper.color = "#767676"; ope.color = "#767676"; ope.visibilte = "hidden"; } else { ope.color = "#767676"; ope.visibilte = "hidden"; } } }

  listOperation(element: ActiviteARealiser) {
    this.fparam.activiteID = element.moniActiviteARealiserID;
    this.displaySpinner = true;
    this.operations = [];
    this.api.listMoOperationAll(this.fparam).subscribe((res) => {
      console.log(res);
      this.operations = res;
      console.log(this.operations);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }
  listMoOperationComptes(element: MoOperation) {
    this.displaySpinner = true;
    this.comptes = [];
    this.api.listMoOperationComptes(element.moOperationID).subscribe((res) => {
      console.log(res);
      this.comptes = res;
      console.log(this.comptes);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }
  listMoMemoireDepense(element: MoOperation) {
    this.depenses = [];
    this.api.listMoMemoireDepense(element.moOperationID).subscribe((res) => {
      console.log(res);
      this.depenses = res;
      console.log(this.depenses);
    }, error => {
      this.displaySpinner = false;
    });
  }
  listAgent() {
    this.fparam.millesime = this.exercice.millesime;
    this.agents = [];
    this.api.listAgent(this.fparam).subscribe((res) => { console.log(res); this.agents = res; });
  }
  getLibelleCompte(operationBudgetaireID: string) {
    for (const ele of this.comptebudgetaire) {
      if (ele.tacheID == operationBudgetaireID) {
        this.opcompte.libelleFr = ele.compteCode + ' - ' + ele.libelleFr;
        this.montantMax = ele.cp;
      }
    }
  }

  node: any;
  async onNodeExpand(event: any) {
    const node = event.node;
    this.node = node;
    if (node.data.activiteID) {
      if (node.data.niveauActiviteID != 4) {
        node.children = await this.getChild(node.data);
      } else {
        node.children = await this.getARList(node.data);
      }
      this.arbre = [...this.arbre];
    }
  }

  async getARList(tache: Activite) {
    this.activite = tache;
    this.fparam.organisationID = this.organisation.organisationID;
    this.fparam.millesime = this.exercice.millesime;
    this.fparam.activiteID = tache.activiteParentID;
    this.fparam.tacheID = tache.activiteID;
    this.fparam.structureID = this.pa.structureID;
    this.fparam.moPlanTravailID = this.pa.moPlanTravailID;
    if (this.fparam.organisationID && this.fparam.millesime && this.fparam.activiteID && this.fparam.tacheID && this.fparam.structureID && this.fparam.moPlanTravailID) {
      this.displaySpinner = true;
      this.activitesAR = [];
      this.arbre3 = [];
      let rs = await this.api.listMoActiviteARealiser(this.fparam).toPromise();
      console.log(rs);
      for await (const item2 of rs) {
        let op: TreeNode = { key: '', data: null, type: '', parent: undefined };
        op.key = item2.moniActiviteARealiserID;
        op.data = item2;
        op.parent = item2.activiteID;
        op.type = 'activiteAR';
        this.arbre3.push(op);
      }
      this.displaySpinner = false;
      return this.arbre3;
    }
    return this.arbre2;
  }



  async getChild(a: Activite) {
    this.arbre2 = [];
    this.loading = true;
    this.displaySpinner = true;
    let rs = await this.api.listMoActivite(this.organisation.organisationID, this.exercice.millesime, this.structure.structureID, a.activiteID, a.niveauActiviteID + 1).toPromise();
    console.log(rs);
    for await (const item2 of rs) {
      let op: TreeNode = { key: '', data: null, type: '', parent: undefined, children: [{ data: {} }], };
      op.key = item2.activiteID;
      op.data = item2;
      op.parent = item2.activiteParentID;
      op.type = 'activite';
      this.arbre2.push(op);
    }
    this.loading = false;
    this.displaySpinner = false;
    return this.arbre2;
  }


  src = 'assets/img/question.png';
  srca = 'assets/img/attention.png';
  messageDialog = false;
  title = '';
  message = '';
  succes(msg: string) { this.srca = 'assets/img/ok.png'; this.title = 'Succes !'; this.message = msg; this.messageDialog = true; }
  erreur(msg: string) { this.srca = 'assets/img/attention.png'; this.title = 'Erreur !'; this.message = msg; this.messageDialog = true; }

  verifyLength(valeur: any) { let val = '' + valeur; if (val.toString().length >= 35) { return true; } return false; }
  defineDescription(libelle: any): string { return libelle.slice(0, 34); }

  verifyLengthOP(valeur: any) { let val = '' + valeur; if (val.toString().length >= 95) { return true; } return false; }
  defineDescriptionOP(libelle: any): string { return libelle.slice(0, 94); }

  verifyLengthSteep(valeur: any) { let val = '' + valeur; if (val.toString().length >= 25) { return true; } return false; }
  defineDescriptionSteep(libelle: any): string { return libelle.slice(0, 24); }


  verifyLengthRec(valeur: any) { let val = '' + valeur; if (val.toString().length >= 110) { return true; } return false; }
  defineDescriptionRec(libelle: any): string { return libelle.slice(0, 109); }


  savePlan() {
    this.pa.activiteARealisers = this.activitesAR;
    this.pa.organisationID = this.organisation.organisationID;
    this.pa.structureID = this.structure.structureID;
    this.pa.millesime = this.exercice.millesime;
    this.pa.user_update = this.ts.getUser().username;
    this.pa.moPointFocaleID = this.pf.moPointFocaleID;
    this.pa.ip_update = '127.0.0.1';
    this.displaySpinner = true;
    console.log(this.pa);
    this.api.savePlan(this.pa).subscribe(data => {
      this.displaySpinner = false;
      this.load();
      this.close();
      this.succes("Enregistrement réussie");
    }, error => { this.displaySpinner = false; this.erreur("Echec d'enregistrement"); })
  }

  modes = [
    { id: 1, label: 'BON DE COMMANDE', value: ModeContractualisation.BCA },
    { id: 2, label: 'MARCHÉ', value: ModeContractualisation.MARCHE },
    { id: 3, label: 'ORDRE DE MISSION', value: ModeContractualisation.MISSION },
  ]


  types: any[] = [
    { id: 1, label: 'AGENT' },
    { id: 2, label: 'STRUCTURE' },
  ]
  saveActivite() {
    this.activiteAR.operations = this.operations;
    this.activiteAR.organisationID = this.organisation.organisationID;
    this.activiteAR.structureID = this.structure.structureID;
    this.activiteAR.millesime = this.exercice.millesime;
    this.activiteAR.user_update = this.ts.getUser().username;
    this.activiteAR.ip_update = '127.0.0.1';
    if (this.activiteAR.typer == 1) {
      this.activiteAR.r = JSON.stringify(this.selectedAR);
    } else {
      this.activiteAR.r = JSON.stringify(this.selectedStrR);
    }
    if (this.activiteAR.typea == 1) {
      this.activiteAR.a = JSON.stringify(this.selectedAA);
    } else {
      this.activiteAR.a = JSON.stringify(this.selectedStrA);
    }
    if (this.activiteAR.typec == 1) { this.activiteAR.c = JSON.stringify(this.selectedAC); } else { this.activiteAR.c = JSON.stringify(this.selectedStrC); }
    if (this.activiteAR.typei == 1) { this.activiteAR.i = JSON.stringify(this.selectedAI); } else { this.activiteAR.i = JSON.stringify(this.selectedStrI); }
    this.displaySpinner = true;
    console.log(this.activiteAR);
    this.api.saveActivite(this.activiteAR).subscribe(data => {
      this.displaySpinner = false;
      this.filtrer(this.activite);
      this.getPA(this.pa, this.actionPA);
      this.succes("successSaveActivite");
    }, error => { this.displaySpinner = false; this.erreur("errorSaveActivite"); })
  }
  saveOperation(operation: MoOperation) {
    if (this.indicateurs.length) {
      operation.indicateurs = this.indicateurs;
    }
    operation.operationComptes = this.comptes;
    operation.memoiredepenses = this.depenses;
    operation.organisationID = this.organisation.organisationID;
    operation.millesime = this.exercice.millesime;
    operation.user_update = this.ts.getUser().username;
    operation.ip_update = '127.0.0.1';
    this.displaySpinner = true;
    console.log(this.activiteAR);
    this.api.saveOperation(this.operation).subscribe(data => {
      this.displaySpinner = false;
      this.operationDialog = false;
      this.listOperation(this.activiteAR);
      this.listMoOperationComptes(operation);
      this.listMoMemoireDepense(operation);
      this.succes("successSaveOperation");
    }, error => { this.displaySpinner = false; this.erreur("errorSaveActivite"); })
  }


  mouseUpActivite(activi: Activite) {
    for (const activ of this.activitesAll) {
      if (activ.activiteID == activi.activiteID && activ.color == "#0066FF") {
        activ.color = "#767676"; activi.color = "#767676"; activi.visibilte = "hidden";
      } else { activi.color = "#767676"; activi.visibilte = "hidden"; }
    }
  }
  decoloreAncienActivite(activi: Activite) {
    for (const activ of this.activitesAll) {
      if (activ.activiteID != activi.activiteID && activ.color == "#0066FF") {
        activ.color = "#767676"; activ.visibilte = "hidden"; activi.color = "#0066FF"; activi.visibilte = "visible";
      } else { activi.color = "#0066FF"; activi.visibilte = "visible"; }
    }
  }
  changeColorActivite(activ: Activite) {
    this.activite = activ;
    for (const activ of this.activitesAll) {
      if (activ.activiteID == activ.activiteID) {
        this.decoloreAncienActivite(activ);
      }
    }
  }
  mouseUpActiviteAR(activi: ActiviteARealiser) {
    for (const activ of this.activitesAR) {
      if (activ.moniActiviteARealiserID == activi.moniActiviteARealiserID && activ.color == "#0066FF") {
        activ.color = "#767676"; activi.color = "#767676"; activi.visibilte = "hidden";
      } else { activi.color = "#767676"; activi.visibilte = "hidden"; }
    }
  }
  decoloreAncienActiviteAR(activi: ActiviteARealiser) {
    for (const activ of this.activitesAR) {
      if (activ.moniActiviteARealiserID != activi.moniActiviteARealiserID && activ.color == "#0066FF") {
        activ.color = "#767676"; activ.visibilte = "hidden"; activi.color = "#0066FF"; activi.visibilte = "visible";
      } else { activi.color = "#0066FF"; activi.visibilte = "visible"; }
    }
  }
  changeColorActiviteAR(activ: ActiviteARealiser) {
    this.activiteAR = activ;
    for (const activ of this.activitesAR) {
      if (activ.moniActiviteARealiserID == activ.moniActiviteARealiserID) {
        this.decoloreAncienActiviteAR(activ);
      }
    }
  }
  pfs: MoPointFocale[] = [];
  listMoPFAll(organisationID: string) {
    this.getOrg(organisationID);
    this.displaySpinner = true;
    this.api.listMoPFByUser(organisationID, this.exercice.millesime, this.ts.getUser().username).subscribe((data) => {
      this.pfs = data;
      console.log(data);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }




  /* *************************************************************************************************** Main d'oeuvre *************************************************************************************************** */
  uo: MoUniteOeuvre = new MoUniteOeuvre();
  uos: MoUniteOeuvre[] = [];

  depense: MoMemoireDepense = new MoMemoireDepense();
  listUo() {
    this.displaySpinner = true;
    this.uos = [];
    this.api.listUo(this.organisation.organisationID, this.exercice.millesime).subscribe((data) => {
      this.uos = data;
      console.log(data);
      this.displaySpinner = false;
    }, error => {
      this.displaySpinner = false;
    });
  }

  getMontantUnite(moUniteOeuvreID: string) {
    this.depense.moUniteOeuvreID = moUniteOeuvreID;
  }

  getUOeuvre(moUniteOeuvreID: string) {
    let uo = new MoUniteOeuvre();
    for (const ele of this.uos) {
      if (ele.moUniteOeuvreID == moUniteOeuvreID) {
        uo = ele;
      }
    }
    return uo;
  }
  addDepense() {
    for (const ele of this.uos) {
      if (ele.moUniteOeuvreID == this.depense.moUniteOeuvreID && this.depense.quantite) {
        this.depense.montant = ele.prixunitaire * this.depense.quantite;
        this.depense.prixunitaire = ele.prixunitaire;
        this.depense.designation = ele.designation;
        this.depense.conditionnement = ele.conditionnement;
      }
    }
    this.depense.moOperationID = this.operation.moOperationID;
    this.depense.moMemoireDepenseID = `MOMED${new Date().toISOString().replace(/[-:]/g, '').replace('T', '').replace(/\..*$/, '')}.${Math.floor(Math.random() * 1000)}.${Math.floor(Math.random() * 1000)}`;
    this.depenses.push(this.depense);
    this.depense = new MoMemoireDepense();
  }
  selectedElement!: any;
  select = false;
  nodeSelect(event: any) {
    if (event.node.data.niveauActiviteID) {
      this.activite = event.node.data;
    } else {
      this.activiteAR = event.node.data;
      this.getAR(event.node.data, 'edit');
    }
    this.select = true;
    this.selectedElement = event.node.data;
    console.log(this.selectedElement);
    console.log(this.selectedNodes);
  }

  onRowDoubleClick(rowData: any): void {
    // Ajoutez ici la logique que vous souhaitez exécuter lors d'un double clic sur une ligne
    console.log('Double clic sur la ligne:', rowData);
    // Par exemple, vous pouvez ouvrir un modal ou naviguer vers une autre page
  }

  /** evenement apres deselection */
  nodeUnselect(event: any) {

  }

  col = [
    { field: '', header: 'N°' },
    { field: 'code', header: 'Code' },
    { field: 'libelleFr', header: 'Designation' },
    { field: 'objectif', header: 'Objectif' },
    { field: 'indicateur', header: 'Indicateurs' },
    { field: 'dateDebut', header: 'Debut' },
    { field: 'dateFin', header: 'Fin' },
    { field: 'montant', header: 'Montant' },
    { field: '', header: 'Actions' },
  ];

  selectID !: string;

  defineType(niveau: number): string { switch (niveau) { case 1: return 'SP'; case 2: return 'AC'; case 3: return 'AT'; case 4: return 'T'; default: return '' } }
  selectedNode1!: TreeNode;

  printDialog = false;
  pdfData: SafeResourceUrl | null = null;
  async exporterPA(): Promise<void> {
    const doc = new jsPDF('landscape');
    const imgWidth = 25;
    const imgHeight = 20;
    const pageWidth = doc.internal.pageSize.getWidth();
    const imgX = (pageWidth - imgWidth) / 2;
    const txtPlan = this.pa.libelleFr;
    const txtExercice = this.exercice.libelleFr;
    const txtPf = this.pf.designationFr;
    const leftText1 = 'REPUBLIQUE DU CAMEROUN';
    const leftTextPlan = 'PLAN D\'ACTION';
    const leftText2 = 'PAIX - TRAVAIL - PATRIE';
    const leftText3 = this.organisation.libelleFr;
    const rightText1 = 'REPUBLIC OF CAMEROON';
    const rightText2 = 'PEACE - WORK - FATHERLAND';
    const rightText3 = this.organisation.libelleUs;
    const rightX = pageWidth - 20;
    const textWidth1 = doc.getStringUnitWidth(rightText1) * 10 / doc.internal.scaleFactor;
    const textWidth2 = doc.getStringUnitWidth(rightText2) * 10 / doc.internal.scaleFactor;
    const textWidth3 = doc.getStringUnitWidth(rightText3) * 10 / doc.internal.scaleFactor;

    const textWidth = doc.getStringUnitWidth(leftTextPlan) * 14 / doc.internal.scaleFactor;
    const startX = (pageWidth - textWidth) / 2;
    const endX = startX + textWidth;

    doc.addImage('assets/apme.png', 'PNG', imgX, 10, imgWidth, imgHeight);
    doc.setFontSize(10);
    doc.text(rightText1, rightX - textWidth1, 20);
    doc.text(leftText1, 15, 20);
    doc.setFontSize(9);
    doc.text(leftText2, 20, 25);
    doc.text(rightText2, rightX - (textWidth2 + 5), 25);
    doc.text(rightText3, rightX - textWidth3, 30);
    doc.text(leftText3, 15, 30);

    doc.setFontSize(12);
    doc.setFont('Helvetica', 'bold');
    doc.text(leftTextPlan, pageWidth / 2, 37, { align: 'center' });
    doc.setFontSize(11);
    doc.setFont('Helvetica', 'normal');
    doc.text(txtPlan, pageWidth / 2, 42, { align: 'center' });
    doc.setFontSize(9);
    doc.setTextColor(128, 128, 128); // Définit la couleur grise (RGB)
    doc.text("Budget : " + txtExercice, 15, 43);
    doc.text("Point Focal : " + txtPf, 15, 48);



    const allChildren = await this.getActivitiesFromLevel1();
    const data = [];

    // Ajouter les données des enfants et des activités à réaliser
    for (const item of allChildren) {
      data.push({
        niveauActiviteID: item.data.niveauActiviteID ? item.data.niveauActiviteID : '',
        code: item.data.code,
        abbreviationFr: item.data.abbreviationFr ? item.data.abbreviationFr : '',
        libelleFr: item.data.libelleFr ? item.data.libelleFr : '',
        objectif: item.data.objectif ? item.data.objectif : '',
        indicateur: item.data.indicateur ? item.data.indicateur : '',
        dateDebut: item.data.dateDebut ? formatDate(new Date(item.data.dateDebut), 'dd/MM/yyyy', 'fr') : '', // Format de la date  
        dateFin: item.data.dateFin ? formatDate(new Date(item.data.dateFin), 'dd/MM/yyyy', 'fr') : '', // Format de la date 
        montant: item.data.montant ? NumberFormatter.formatWithThousandSeparator(item.data.montant) : 0
      });
    }


    // Générer le PDF avec js-autoTable
    const totalWidth = doc.internal.pageSize.getWidth();
    autoTable(doc, {
      head: [['CODE', 'STRUCTURE', 'DÉSIGNATION', 'OBJECTIFS', 'INDICATEURS', 'DEBUT', 'FIN', 'COÛTS']],
      body: data.map(item => {
        /* Les Taches */
        if ([4].includes(item.niveauActiviteID)) {
          return [
            { content: item.code + " - " + item.abbreviationFr + "  " + item.libelleFr, colSpan: 7, styles: { fillColor: '#d8d8d8', fontStyle: 'bold' } },
            '', // abbreviationFr  
            '', // Objectif  
            '', // Objectif  
            '', // Indicateur  
            '', // Début  
            '', // Fin  
            { content: item.montant, styles: { fillColor: '#d8d8d8', fontStyle: 'bold' } },
          ];
          /* Les PG, AC, AT */
        } else if ([1, 2, 3].includes(item.niveauActiviteID)) {
          return [
            { content: item.code, styles: { valign: 'middle', halign: 'left', fontStyle: 'bold' } },
            item.abbreviationFr,
            { content: item.libelleFr, colSpan: 6, styles: { fillColor: '#eaeaea', fontStyle: 'normal' } },
            '', // Objectif  
            '', // Indicateur  
            '', // Début  
            '', // Fin  
            ''  // Montant  
          ];
        }
        /* Les actvités à réaliser */
        return [
          { content: item.code, styles: { valign: 'middle', halign: 'left', fontStyle: 'bold', textColor: '#007ad9' } },
          item.abbreviationFr,
          item.libelleFr,
          item.objectif,
          item.indicateur,
          item.dateDebut,
          item.dateFin,
          item.montant
        ];
      }),
      startY: 53,
      theme: 'grid',
      headStyles: { fillColor: [23, 74, 125], textColor: [255, 255, 255], fontStyle: 'bold', fontSize: 7, valign: 'middle', },
      columnStyles: {
        0: { valign: 'middle', halign: 'left', fontSize: 9, fontStyle: 'bold', cellWidth: (totalWidth * 0.05) },
        1: { valign: 'middle', halign: 'left', fontSize: 9, fontStyle: 'bold', cellWidth: (totalWidth * 0.05) },
        2: { valign: 'middle', halign: 'left', fontSize: 8, fontStyle: 'normal', cellWidth: (totalWidth * 0.25) },
        3: { valign: 'middle', halign: 'left', fontSize: 9, fontStyle: 'normal' },
        4: { valign: 'middle', halign: 'left', fontSize: 9, fontStyle: 'normal' },
        5: { valign: 'middle', halign: 'left', fontSize: 9, fontStyle: 'normal' },
        6: { valign: 'middle', halign: 'left', fontSize: 9, fontStyle: 'normal' },
        7: { valign: 'middle', halign: 'right', fontSize: 7.1, fontStyle: 'bold', cellWidth: (totalWidth * 0.08) },
      },

    });

    const pdfData = doc.output('datauristring');
    this.pdfData = this.sanitizer.bypassSecurityTrustResourceUrl(pdfData); // Sanitize the URL
    this.printDialog = true; // Ouvre la boîte de dialogue
  }


  /* async getAllChildrenWithAR(activite: any) {
    const children = await this.getChild(activite);
    const op: TreeNode = { key: activite.activiteID, data: activite, type: 'activite', parent: undefined, children: [{ data: {} }], };
    let allChildren: any[] = [];
    if (op.data.niveauActiviteID === 1) { allChildren.push(op); }
    for (const child of children) {
      allChildren.push(child);
      if (child.data.niveauActiviteID === 4) {
        const activitiesAR = await this.getARList(child.data);
        child.data.montant = activitiesAR.reduce((sum, ar) => sum + ar.data.montant, 0);
        console.log(child.data);
        allChildren = allChildren.concat(activitiesAR);
      } else {
        const childChildren = await this.getAllChildrenWithAR(child.data);
        allChildren = allChildren.concat(childChildren);
      }
    }
    return allChildren;
  } */

  async getAllChildrenWithAR(activite: any) {
    const children = await this.getChild(activite);
    const op: TreeNode = { key: activite.activiteID, data: activite, type: 'activite', parent: undefined, children: [] };
    let allChildren: any[] = [];
    
    if (op.data.niveauActiviteID === 1) { allChildren.push(op); }
    
    for (const child of children) {
        allChildren.push(child);
        if (child.data.niveauActiviteID === 4) {
            const activitiesAR = await this.getARList(child.data);
           /*  // Filtrer les activiteAR pour ceux dont tacheID correspond à activiteID
            const filteredAR = activitiesAR.filter(ar => ar.data.tacheID === child.data.activiteID);
            // Calculer le montant total
            child.data.montant = filteredAR.reduce((sum, ar) => sum + ar.data.montant, 0);
            console.log(child.data); */
            allChildren = allChildren.concat(activitiesAR);
        } else {
            const childChildren = await this.getAllChildrenWithAR(child.data);
            allChildren = allChildren.concat(childChildren);
        }
    }
    
    return allChildren;
}


  async getActivitiesFromLevel1() {
    const level1Activities = await this.api.listMoActivite(this.organisation.organisationID, this.exercice.millesime, this.structure.structureID, "a.activiteID", 1).toPromise();
    let allData: any[] = [];
    for (const activite of level1Activities) {
      const childrenWithAR = await this.getAllChildrenWithAR(activite);
      allData = allData.concat(childrenWithAR);
    }
    return allData;
  }





  onDragOver(event: DragEvent) {
    event.preventDefault();
    this.dropText = "Release to upload";
  }

  onDragLeave(event: DragEvent) {
    event.preventDefault();
    this.dropText = this.defaultText;
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    const files = event.dataTransfer?.files; // files peut être undefined
    this.handleFiles(files || null); // Si files est undefined, on passe null
  }

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files) {
      this.handleFiles(input.files);
    }
  }

  handleFiles(files: FileList | null) {
    if (files && files.length > 0) {
      const file = files[0]; // On prend le premier fichier
      if (file.type !== 'application/pdf') {
        this.fileTypeError = true;
        this.dropText = "File type must be PDF";
        this.pdfUrl = null; // Réinitialiser l'URL si le type est incorrect
      } else {
        this.fileTypeError = false;
        this.dropText = "File uploaded successfully!";
        
        // Stocker le fichier dans la propriété
        this.uploadedFile = file;

        // Créer une URL pour le fichier et la sécuriser
        const fileUrl = URL.createObjectURL(file);
        this.pdfUrl = this.sanitizer.bypassSecurityTrustResourceUrl(fileUrl);
        this.fileUploaded = true; // Indiquer que le fichier a été téléchargé

        // Simuler une progression de chargement
        this.uploadProgress = 0;
        const interval = setInterval(() => {
          this.uploadProgress += 10;
          if (this.uploadProgress >= 100) {
            clearInterval(interval);
            this.uploadProgress = 100; // Assurez-vous que la progression atteint 100
          }
        }, 200); // Simuler le chargement par intervalles de 200ms
      }
    }
  }

  removeFile() {
    this.pdfUrl = null; // Réinitialiser l'URL
    this.fileUploaded = false; // Réinitialiser l'état du fichier
    this.uploadProgress = 0; // Réinitialiser la progression
    this.uploadedFile = null; // Réinitialiser le fichier
    this.dropText = this.defaultText; // Réinitialiser le texte
  }
}
