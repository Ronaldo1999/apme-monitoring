import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-board-moderator',
  templateUrl: './board-moderator.component.html',
  styleUrls: ['./board-moderator.component.scss']
})
export class BoardModeratorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
